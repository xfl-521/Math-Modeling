# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：特征图可视化.py
    @时间：2025/9/23 21:00
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""

import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pyts.image import GramianAngularField, MarkovTransitionField
from sklearn.preprocessing import MinMaxScaler
from skimage.feature import graycomatrix, graycoprops


def signal2img(ts, img_size=224, Q=8, plot=False, figsize=(15, 4), titles=None):
    """
    把一维振动信号转成 GASF / GADF / MTF，并可一键画热力图

    参数
    ----
    ts : array-like, shape (T,)
        原始一维序列
    img_size : int or None
        输出图像边长；None 则保持原长
    Q : int, default 8
        MTF 分桶数
    plot : bool, default False
        是否直接弹出热力图
    figsize : tuple
        三子图画布大小
    titles : list of str or None
        三张子图标题，None 则用默认

    返回
    ----
    gasf : ndarray, shape (img_size, img_size)
    gadf : ndarray, shape (img_size, img_size)
    mtf  : ndarray, shape (img_size, img_size)
    """
    ts = np.asarray(ts, dtype=float).ravel()

    # 可选长度对齐
    if img_size is not None and len(ts) != img_size:
        ts = np.interp(np.linspace(0, 1, img_size),
                       np.linspace(0, 1, len(ts)), ts)

    # 归一化 [0,1]
    ts = MinMaxScaler().fit_transform(ts.reshape(-1, 1))[:, 0]

    # 生成图像
    ts_2d = ts.reshape(1, -1)
    gasf = GramianAngularField(method='summation').fit_transform(ts_2d)[0]
    gadf = GramianAngularField(method='difference').fit_transform(ts_2d)[0]
    mtf = MarkovTransitionField(n_bins=Q).fit_transform(ts_2d)[0]

    # 可视化
    if plot:
        if titles is None:
            titles = ['GASF', 'GADF', 'MTF']
        sns.set_style("white")
        fig, ax = plt.subplots(1, 3, figsize=figsize)
        for a, mat, title in zip(ax, [gasf, gadf, mtf], titles):
            sns.heatmap(mat, cmap='jet', ax=a, cbar=True,
                        xticklabels=False, yticklabels=False)
            a.set_title(title)
        plt.tight_layout()
        plt.savefig('GASF-GADF-MTF.tif')
        plt.show()

    return gasf, gadf, mtf





import numpy as np
from scipy import signal
from typing import Tuple, Optional


def time2freq(x: np.ndarray,
              fs: float,
              window: str = 'hann',
              nperseg: Optional[int] = None,
              noverlap: Optional[int] = None) -> Tuple[np.ndarray,
                                                   np.ndarray,
                                                   np.ndarray]:
    """
    把一维振动时域信号转成频域结果。

    参数
    ----
    x : 1-D ndarray
        时域采样序列（任意长度，自动拷贝）。
    fs : float
        采样频率 [Hz]。
    window : str, optional
        Welch 法所用窗函数，默认 'hann'。
    nperseg : int, optional
        每段长度，默认 None 表示 256 或更小的 2 的幂。
    noverlap : int, optional
        段间重叠点数，默认 None 表示 nperseg//2。

    返回
    ----
    freq : 1-D ndarray
        频率轴 [Hz]，范围 0 … fs/2。
    amp_spec : 1-D ndarray
        单侧幅值谱（已归一化，与原始信号单位一致）。
    psd : 1-D ndarray
        功率谱密度 [V²/Hz]（或原始单位²/Hz）。
    """
    x = np.asarray(x, dtype=float).ravel()
    N = x.size

    # ---- 1. 快速傅里叶幅值谱（单侧） ----
    N_fft = 1 << int(np.ceil(np.log2(N)))      # 向上取 2 的幂，提速
    X_fft = np.fft.fft(x, n=N_fft)
    freq_full = np.fft.fftfreq(N_fft, d=1/fs)
    half = N_fft // 2
    freq = freq_full[:half]

    amp_spec = np.abs(X_fft)[:half]
    amp_spec[1:] *= 2 / N          # 归一化，除直流
    amp_spec[0] /= N

    return freq, amp_spec


# ---------------- 使用示例 ----------------
if __name__ == "__main__":

    file_path = 'DataALL/B7/12kHz_DE_data_B_0007_B007_0_X118_DE_time.xlsx'

    # 读取数据，不读第一行
    data = pd.read_excel(file_path)
    # 裁切数据
    info = data.iloc[1:, :3]
    value = data.iloc[1:, 3:].values

    sensor = value[100]


    freq, amp = time2freq(sensor, fs=1024)

    # 画图
    plt.figure(figsize=(10, 4))
    plt.subplot(1, 2, 1)
    plt.plot(freq, amp)
    plt.title("Amplitude Spectrum")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("Amplitude")
    plt.xlim(0, 1024 / 2)
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.semilogy(freq, amp)
    plt.title("PSD (Welch)")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("PSD [V²/Hz]")
    plt.xlim(0, fs / 2)
    plt.grid(True)

    plt.tight_layout()
    plt.show()

    # 绘制图

    gasf_img, gadf_img, mtf_img = signal2img(sensor, img_size=224, plot=True)






