# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：mat数据提取.py
    @时间：2025/9/21 17:59
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import numpy as np
import os
import scipy.io
import pandas as pd

path = 'dataset\\rootdata'

# 遍历文件夹下子文件夹中的所有文件
for root, dirs, files in os.walk(path):
    for file in files:
        file_path = os.path.join(root, file)

        # 分割出二级根目录名称
        root_name = os.path.dirname(root)
        # 以\\分割
        root_name = root_name.split('\\')[-2]
        try:
            mat = scipy.io.loadmat(file_path)
        except Exception as e:
            print(f"读取失败: {file_path}, 错误: {e}")
            continue

        keys = [key for key in mat.keys() if not key.startswith('__')]
        for key in keys:
            if key != 'RPM':
                data = mat[key]
                if isinstance(data, np.ndarray):
                    data = data.flatten()
                    print(len(data))
                    rows = []
                    # 以400的步长，1200的长度进行滑动截取，并拼接为二维数据
                    for i in range(0, len(data)-1200, 400):
                        data_row_slice = data[i:i+1200]
                        rows.append(data_row_slice)
                    rows = np.array(rows)
                    rows = pd.DataFrame(rows)
                    # 保存到CSV文件，将路径名和key作为新文件名
                    output_file = os.path.join('400步长1200长度滑移数据', f'{root_name}_{file}_{key}.csv')
                    rows.to_csv(output_file, index=False)

