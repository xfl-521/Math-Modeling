"""
从三张 2D 图像（GASF/GADF/MTF）提取 GLCM 纹理特征
依赖：pip install scikit-image numpy
"""
import numpy as np
from skimage.feature import graycomatrix, graycoprops

def glcm_features(img, distances=None, angles=None, levels=256, symmetric=True, normed=True):
    """
    计算单张图像的 GLCM 及 8 个纹理特征

    参数
    ----
    img : ndarray
        2-D 图像，值域 [0,1] 或 [0,255] 均可
    distances : list, default [1]
        像素间距
    angles : list, default [0, π/4, π/2, 3π/4]
        方向（弧度）
    levels : int, default 256
        灰度级量化层数
    symmetric / normed : bool
        是否对称、归一化 GLCM

    返回
    ----
    glcm : ndarray, shape (len(distances), len(angles), levels, levels)
    features : dict
        8 个纹理特征，键见下
    """
    if distances is None:
        distances = [1]
    if angles is None:
        angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]

    # 0–1 → 0–255 量化
    img = (img * (levels-1)).astype(np.uint8)

    glcm = graycomatrix(img,
                        distances=distances,
                        angles=angles,
                        levels=levels,
                        symmetric=symmetric,
                        normed=normed)

    # 把 4 个方向平均，得到旋转不变特征（可选）
    glcm_mean = glcm.mean(axis=3, keepdims=True)   # 平均角度
    glcm_mean = glcm_mean.mean(axis=2, keepdims=True)  # 平均距离（如只需整体特征）

    # 8 个经典特征
    features = {
        'contrast'     : graycoprops(glcm, 'contrast').mean(),
        'dissimilarity': graycoprops(glcm, 'dissimilarity').mean(),
        'homogeneity'  : graycoprops(glcm, 'homogeneity').mean(),
        'energy'       : graycoprops(glcm, 'energy').mean(),
        'correlation'  : graycoprops(glcm, 'correlation').mean(),
        'ASM'          : graycoprops(glcm, 'ASM').mean(),
        'entropy'      : -np.sum(glcm*np.log2(glcm+1e-12)),  # 手动算熵
        'auto_correlation': graycoprops(glcm, 'correlation').mean()  # 同 correlation
    }
    return glcm, features


def batch_glcm(imgs, names=None, **kwargs):
    """
    批量提取多张图的 GLCM 特征

    参数
    ----
    imgs : list of ndarray
    names : list of str or None
        对应图像名字，用于打印/字典键
    **kwargs : 全部透传给 glcm_features

    返回
    ----
    df : dict
        {name: features_dict}
    """
    if names is None:
        names = [f'img{i}' for i in range(len(imgs))]
    return {n: glcm_features(im, **kwargs)[1] for n, im in zip(names, imgs)}


# ---------------- 使用示例 ----------------
if __name__ == "__main__":
    # 假设已有三张图（来自前面的 signal2img）
    # gasf, gadf, mtf = signal2img(x, img_size=128)

    # 这里用随机矩阵演示
    gasf = np.random.rand(128, 128)
    gadf = np.random.rand(128, 128)
    mtf = np.random.rand(128, 128)

    # 一键提取
    feats = batch_glcm([gasf, gadf, mtf],
                       names=['GASF', 'GADF', 'MTF'],
                       distances=[1, 2, 3],  # 多尺度
                       levels=64)            # 量化 64 级，省内存

    # 打印结果
    import pandas as pd
    df = pd.DataFrame(feats).T
    print(df.round(4))