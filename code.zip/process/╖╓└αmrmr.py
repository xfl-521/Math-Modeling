# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：分类mrmr.py
    @时间：2025/9/22 23:37
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import numpy as np
from sklearn.feature_selection import mutual_info_classif
from itertools import combinations

def mrmr_ranking(X, y, n_selected=None):
    """
    最大相关最小冗余特征排序（MRMR）

    参数
    ----
    X : ndarray, shape (n_samples, n_features)
    y : ndarray, shape (n_samples,)
    n_selected : int or None
        返回前 n_selected 个特征索引；None 则返回全部排序

    返回
    ----
    ranking : list
        按 MRMR 得分降序排列的特征索引
    score : list
        对应每一步的 MRMR 得分（越大越好）
    """
    n_samples, n_features = X.shape
    if n_selected is None:
        n_selected = n_features

    # 1. 计算特征-类别互信息（Max-Relevance）
    mi_fc = mutual_info_classif(X, y, random_state=42)  # shape (n_features,)

    # 2. 计算特征-特征互信息（Redundancy）
    mi_ff = np.zeros((n_features, n_features))
    for i, j in combinations(range(n_features), 2):
        mi = mutual_info_classif(X[:, [i, j]], y, random_state=42)[0]  # 只取 i vs j
        mi_ff[i, j] = mi_ff[j, i] = mi

    # 3. 贪心选择
    selected = []          # 已选特征索引
    remaining = list(range(n_features))
    score = []

    while len(selected) < n_selected:
        if not selected:   # 第 1 步：直接选 MI 最大
            best = np.argmax(mi_fc)
        else:
            # MRMR 得分 = MI(f,c) - 平均 MI(f,已选)
            rel = mi_fc[remaining]
            red = mi_ff[np.ix_(remaining, selected)].mean(axis=1)
            s = rel - red
            best_idx = np.argmax(s)
            best = remaining[best_idx]
            score.append(s[best_idx])

        selected.append(best)
        remaining.remove(best)

    return selected, score


# ---------------- 使用示例 ----------------
if __name__ == "__main__":
    from sklearn.datasets import load_wine
    import pandas as pd

    data = load_wine()

    data = pd.read_csv('ALL(2).csv', encoding='gbk').values
    X = data[:, :-1]
    y = data[:, -1]

    ranking, sc = mrmr_ranking(X, y, n_selected=10)
    print("MRMR 排序（前 10）：", ranking)
    print("对应得分：", np.round(sc, 4))

    # 友好展示
    df = pd.DataFrame({
        'feature_idx': ranking,
        'feature_name': [data.feature_names[i] for i in ranking],
        'MI_with_target': mutual_info_classif(X, y)[ranking]
    })
    print(df.head(10))