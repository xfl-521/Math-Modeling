# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：振动信号一维特征提取.py
    @时间：2025/9/22 12:50
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import numpy as np
import pandas as pd
from scipy import signal, stats
from scipy.fft import fft, fftfreq
from scipy.spatial.distance import pdist, squareform
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

import numpy as np
from itertools import permutations
from math import factorial, log
from scipy.spatial.distance import cdist
import warnings

warnings.filterwarnings('ignore')


class VibrationFeatureExtractor:
    """振动信号特征提取器"""

    def __init__(self, sampling_rate=1000):
        """
        初始化特征提取器

        Parameters:
        sampling_rate: 采样频率 (Hz)
        """
        self.fs = sampling_rate

    def time_domain_features(self, signal_data):
        """
        提取时域特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 时域特征字典
        """
        features = {}

        # 基础统计特征
        features['mean'] = np.mean(signal_data)  # 均值
        features['std'] = np.std(signal_data)  # 标准差
        features['var'] = np.var(signal_data)  # 方差
        features['rms'] = np.sqrt(np.mean(signal_data ** 2))  # 均方根值

        # 峰值特征
        features['max'] = np.max(signal_data)  # 最大值
        features['min'] = np.min(signal_data)  # 最小值
        features['peak_to_peak'] = features['max'] - features['min']  # 峰峰值
        features['peak'] = max(abs(features['max']), abs(features['min']))  # 峰值

        # 形状特征
        features['skewness'] = stats.skew(signal_data)  # 偏度
        features['kurtosis'] = stats.kurtosis(signal_data)  # 峭度

        # 脉冲指标
        if features['mean'] != 0:
            features['crest_factor'] = features['peak'] / features['rms']  # 波峰因子
            features['clearance_factor'] = features['peak'] / (np.mean(np.sqrt(np.abs(signal_data)))) ** 2  # 裕度因子
            features['shape_factor'] = features['rms'] / np.mean(np.abs(signal_data))  # 波形因子
            features['impulse_factor'] = features['peak'] / np.mean(np.abs(signal_data))  # 脉冲因子
        else:
            features['crest_factor'] = 0
            features['clearance_factor'] = 0
            features['shape_factor'] = 0
            features['impulse_factor'] = 0

        # 能量特征
        features['energy'] = np.sum(signal_data ** 2)  # 信号能量
        features['power'] = features['energy'] / len(signal_data)  # 平均功率

        return features

    def frequency_domain_features(self, signal_data):
        """
        提取频域特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 频域特征字典
        """
        features = {}

        # 计算FFT
        fft_vals = fft(signal_data)
        freqs = fftfreq(len(signal_data), 1 / self.fs)

        # 只取正频率部分
        n = len(signal_data) // 2
        freqs = freqs[:n]
        fft_magnitude = np.abs(fft_vals[:n])
        fft_power = fft_magnitude ** 2

        # 频域基础特征
        features['spectral_centroid'] = np.sum(freqs * fft_power) / np.sum(fft_power)  # 频谱重心
        features['spectral_spread'] = np.sqrt(np.sum(((freqs - features['spectral_centroid']) ** 2) * fft_power) / np.sum(fft_power))  # 频谱扩展度
        features['spectral_rolloff'] = self._spectral_rolloff(freqs, fft_power, 0.85)  # 频谱滚降点
        features['spectral_flux'] = np.sum(np.diff(fft_magnitude) ** 2)  # 频谱流量

        # 主频特征
        dominant_freq_idx = np.argmax(fft_magnitude)
        features['dominant_frequency'] = freqs[dominant_freq_idx]  # 主频
        features['dominant_magnitude'] = fft_magnitude[dominant_freq_idx]  # 主频幅值

        # 频带能量特征
        features['total_power'] = np.sum(fft_power)  # 总功率

        # 定义频带范围
        low_freq_mask = (freqs >= 0) & (freqs < self.fs / 8)
        mid_freq_mask = (freqs >= self.fs / 8) & (freqs < self.fs / 4)
        high_freq_mask = (freqs >= self.fs / 4) & (freqs < self.fs / 2)

        features['low_freq_power'] = np.sum(fft_power[low_freq_mask])  # 低频功率
        features['mid_freq_power'] = np.sum(fft_power[mid_freq_mask])  # 中频功率
        features['high_freq_power'] = np.sum(fft_power[high_freq_mask])  # 高频功率

        # 频率分布特征
        if features['total_power'] > 0:
            features['low_freq_ratio'] = features['low_freq_power'] / features['total_power']
            features['mid_freq_ratio'] = features['mid_freq_power'] / features['total_power']
            features['high_freq_ratio'] = features['high_freq_power'] / features['total_power']
        else:
            features['low_freq_ratio'] = 0
            features['mid_freq_ratio'] = 0
            features['high_freq_ratio'] = 0

        # 频谱峭度和偏度
        features['spectral_kurtosis'] = stats.kurtosis(fft_magnitude)
        features['spectral_skewness'] = stats.skew(fft_magnitude)

        return features

    def time_frequency_features(self, signal_data, nperseg=256):
        """
        提取时频域特征

        Parameters:
        signal_data: 一维振动信号数组
        nperseg: STFT窗口长度

        Returns:
        dict: 时频域特征字典
        """
        features = {}

        # 短时傅里叶变换 (STFT)
        f, t, Zxx = signal.stft(signal_data, fs=self.fs, nperseg=nperseg)
        stft_magnitude = np.abs(Zxx)
        stft_power = stft_magnitude ** 2

        # 时频域基础特征
        features['stft_mean'] = np.mean(stft_magnitude)  # STFT幅值均值
        features['stft_std'] = np.std(stft_magnitude)  # STFT幅值标准差
        features['stft_max'] = np.max(stft_magnitude)  # STFT最大幅值
        features['stft_energy'] = np.sum(stft_power)  # STFT总能量

        # 瞬时频率特征
        instantaneous_freq = self._instantaneous_frequency(signal_data)
        features['inst_freq_mean'] = np.mean(instantaneous_freq)  # 瞬时频率均值
        features['inst_freq_std'] = np.std(instantaneous_freq)  # 瞬时频率标准差
        features['inst_freq_range'] = np.ptp(instantaneous_freq)  # 瞬时频率范围

        # 时频集中度
        features['time_concentration'] = self._time_concentration(stft_power)
        features['freq_concentration'] = self._frequency_concentration(stft_power)

        # 小波变换特征
        wavelet_features = self._wavelet_features(signal_data)
        features.update(wavelet_features)

        return features

    def entropy_features(self, signal_data):
        """
        提取熵特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 熵特征字典
        """
        features = {}

        # 近似熵 (Approximate Entropy)
        features['approximate_entropy'] = self._approximate_entropy(signal_data, m=2, r=0.2)

        # 样本熵 (Sample Entropy)
        features['sample_entropy'] = self._sample_entropy(signal_data, m=2, r=0.2)

        # 模糊熵 (Fuzzy Entropy)
        features['fuzzy_entropy'] = self._fuzzy_entropy(signal_data, m=2, r=0.2)

        # 排列熵 (Permutation Entropy)
        features['permutation_entropy'] = self._permutation_entropy(signal_data, m=3)

        return features

    def fractal_dimension_features(self, signal_data):
        """
        提取表观分形维数特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 分形维数特征字典
        """
        features = {}

        # Richardson表观分形维数
        features['richardson_fd'] = self._richardson_fractal_dimension(signal_data)

        # Kolmogorov表观分形维数
        features['kolmogorov_fd'] = self._kolmogorov_fractal_dimension(signal_data)

        # Minkowski表观分形维数
        features['minkowski_fd'] = self._minkowski_fractal_dimension(signal_data)

        # Korcak表观分形维数
        features['korcak_fd'] = self._korcak_fractal_dimension(signal_data)

        return features

    def _approximate_entropy(self, data, m=2, r=0.2):
        """计算近似熵"""
        N = len(data)

        def _patterns(m):
            patterns = np.array([data[i:i + m] for i in range(N - m + 1)])
            return patterns

        def _maxdist(xi, xj, m):
            return max([abs(ua - va) for ua, va in zip(xi, xj)])

        def _phi(m):
            patterns = _patterns(m)
            C = np.zeros(N - m + 1)
            for i in range(N - m + 1):
                template_i = patterns[i]
                for j in range(N - m + 1):
                    if _maxdist(template_i, patterns[j], m) <= r * np.std(data):
                        C[i] += 1.0
            phi = np.mean(np.log(C / float(N - m + 1)))
            return phi

        return _phi(m) - _phi(m + 1)

    def _sample_entropy(self, data, m=2, r=0.2):
        """计算样本熵"""
        N = len(data)

        def _patterns(m):
            patterns = np.array([data[i:i + m] for i in range(N - m + 1)])
            return patterns

        def _maxdist(xi, xj, m):
            return max([abs(ua - va) for ua, va in zip(xi, xj)])

        patterns_m = _patterns(m)
        patterns_m1 = _patterns(m + 1)

        A = 0
        B = 0
        r_scaled = r * np.std(data)

        for i in range(N - m):
            template_m = patterns_m[i]
            template_m1 = patterns_m1[i]

            for j in range(i + 1, N - m):
                if _maxdist(template_m, patterns_m[j], m) <= r_scaled:
                    B += 1
                    if _maxdist(template_m1, patterns_m1[j], m + 1) <= r_scaled:
                        A += 1

        if B == 0:
            return float('inf')
        return -np.log(A / B)

    def _fuzzy_entropy(self, data, m=2, r=0.2):
        """计算模糊熵"""
        N = len(data)

        def _fuzzy_function(d, n, r):
            return np.exp(-(d ** n) / r)

        def _patterns(m):
            patterns = np.array([data[i:i + m] for i in range(N - m + 1)])
            return patterns

        def _maxdist(xi, xj):
            return max([abs(ua - va) for ua, va in zip(xi, xj)])

        patterns_m = _patterns(m)
        patterns_m1 = _patterns(m + 1)

        phi_m = 0
        phi_m1 = 0
        r_scaled = r * np.std(data)

        for i in range(N - m):
            sim_m = 0
            sim_m1 = 0

            for j in range(N - m):
                if i != j:
                    d_m = _maxdist(patterns_m[i], patterns_m[j])
                    sim_m += _fuzzy_function(d_m, 2, r_scaled)

                    if j < N - m:
                        d_m1 = _maxdist(patterns_m1[i], patterns_m1[j])
                        sim_m1 += _fuzzy_function(d_m1, 2, r_scaled)

            phi_m += np.log(sim_m / (N - m - 1)) if sim_m > 0 else 0
            phi_m1 += np.log(sim_m1 / (N - m - 1)) if sim_m1 > 0 else 0

        phi_m /= (N - m)
        phi_m1 /= (N - m)

        return phi_m - phi_m1

    def _permutation_entropy(self, data, m=3):
        """计算排列熵"""
        N = len(data)

        # 生成所有可能的排列模式
        permutation_patterns = list(permutations(range(m)))
        pattern_count = {pattern: 0 for pattern in permutation_patterns}

        # 统计每种排列模式的出现次数
        for i in range(N - m + 1):
            segment = data[i:i + m]
            # 获取排序索引
            sorted_indices = sorted(range(m), key=lambda k: segment[k])
            pattern = tuple(sorted_indices)
            if pattern in pattern_count:
                pattern_count[pattern] += 1

        # 计算相对频率
        total_patterns = N - m + 1
        probabilities = [count / total_patterns for count in pattern_count.values() if count > 0]

        # 计算排列熵
        pe = -sum(p * log(p) for p in probabilities if p > 0)

        # 归一化
        max_entropy = log(factorial(m))
        return pe / max_entropy if max_entropy > 0 else 0

    def _richardson_fractal_dimension(self, data):
        """计算Richardson表观分形维数"""
        N = len(data)
        scales = np.arange(1, min(N // 4, 20))
        lengths = []

        for scale in scales:
            # 重采样数据
            resampled_indices = np.arange(0, N, scale)
            resampled_data = data[resampled_indices]

            # 计算路径长度
            if len(resampled_data) > 1:
                path_length = np.sum(np.abs(np.diff(resampled_data)))
                lengths.append(path_length)
            else:
                lengths.append(0)

        # 拟合log(length) vs log(scale)的斜率
        if len(lengths) > 2:
            log_scales = np.log(scales[:len(lengths)])
            log_lengths = np.log(np.array(lengths) + 1e-12)  # 避免log(0)

            # 线性回归
            coeffs = np.polyfit(log_scales, log_lengths, 1)
            fractal_dimension = 1 - coeffs[0]  # Richardson维数
            return max(1, min(2, fractal_dimension))  # 限制在合理范围内

        return 1.0

    def _kolmogorov_fractal_dimension(self, data):
        """计算Kolmogorov表观分形维数（基于相关维数）"""
        # 重构相空间
        m = 3  # 嵌入维数
        tau = 1  # 延迟时间
        N = len(data)

        # 相空间重构
        if N < m + (m - 1) * tau:
            return 1.0

        embedded_data = np.zeros((N - (m - 1) * tau, m))
        for i in range(m):
            embedded_data[:, i] = data[i * tau:N - (m - 1) * tau + i * tau]

        # 计算距离矩阵
        distances = squareform(pdist(embedded_data))

        # 不同尺度下的相关积分
        scales = np.logspace(-2, 0, 10) * np.std(distances)
        correlation_integrals = []

        for r in scales:
            # 计算相关积分
            correlation_sum = np.sum(distances < r) - len(distances)  # 排除对角线
            total_pairs = len(distances) * (len(distances) - 1)
            correlation_integral = correlation_sum / total_pairs if total_pairs > 0 else 0
            correlation_integrals.append(correlation_integral + 1e-12)

        # 计算相关维数
        log_r = np.log(scales)
        log_c = np.log(correlation_integrals)

        # 线性拟合
        valid_indices = ~np.isinf(log_c) & ~np.isnan(log_c)
        if np.sum(valid_indices) > 2:
            coeffs = np.polyfit(log_r[valid_indices], log_c[valid_indices], 1)
            correlation_dimension = coeffs[0]
            return max(0, min(3, correlation_dimension))

        return 1.0

    def _minkowski_fractal_dimension(self, data):
        """计算Minkowski表观分形维数（盒子维数）"""
        # 将信号转换为二维曲线
        N = len(data)
        x = np.arange(N)
        y = data

        # 归一化到单位正方形
        x_norm = (x - x.min()) / (x.max() - x.min()) if x.max() != x.min() else x
        y_norm = (y - y.min()) / (y.max() - y.min()) if y.max() != y.min() else y

        # 不同的盒子尺寸
        box_sizes = np.logspace(-3, -0.5, 15)
        box_counts = []

        for box_size in box_sizes:
            # 计算需要的盒子数量
            x_boxes = int(np.ceil(1.0 / box_size))
            y_boxes = int(np.ceil(1.0 / box_size))

            # 创建网格
            occupied_boxes = set()

            for i in range(len(x_norm)):
                # 确定点在哪个盒子中
                x_box = int(x_norm[i] / box_size)
                y_box = int(y_norm[i] / box_size)

                # 限制在网格范围内
                x_box = min(x_box, x_boxes - 1)
                y_box = min(y_box, y_boxes - 1)

                occupied_boxes.add((x_box, y_box))

            box_counts.append(len(occupied_boxes))

        # 计算分形维数
        log_box_sizes = np.log(box_sizes)
        log_box_counts = np.log(np.array(box_counts) + 1)

        # 线性回归
        coeffs = np.polyfit(log_box_sizes, log_box_counts, 1)
        minkowski_dimension = -coeffs[0]

        return max(1, min(2, minkowski_dimension))

    def _korcak_fractal_dimension(self, data):
        """计算Korcak表观分形维数（基于峰值统计）"""
        # 寻找局部极大值
        peaks, _ = signal.find_peaks(data)

        if len(peaks) < 10:  # 如果峰值太少，返回默认值
            return 1.0

        # 计算峰值高度
        peak_heights = data[peaks]

        # 对峰值高度进行排序
        sorted_heights = np.sort(peak_heights)[::-1]  # 降序

        # 计算不同阈值下的峰值数量
        thresholds = np.linspace(sorted_heights.min(), sorted_heights.max(), 20)
        peak_counts = []

        for threshold in thresholds:
            count = np.sum(sorted_heights >= threshold)
            peak_counts.append(count)

        # 只保留有效的数据点
        valid_indices = np.array(peak_counts) > 0
        if np.sum(valid_indices) < 3:
            return 1.0

        log_thresholds = np.log(thresholds[valid_indices] + 1e-12)
        log_counts = np.log(np.array(peak_counts)[valid_indices])

        # 线性拟合
        try:
            coeffs = np.polyfit(log_thresholds, log_counts, 1)
            korcak_dimension = -coeffs[0]
            return max(0, min(2, korcak_dimension))
        except:
            return 1.0

        return features

    def _spectral_rolloff(self, freqs, power, rolloff_ratio=0.85):
        """计算频谱滚降点"""
        cumulative_power = np.cumsum(power)
        total_power = cumulative_power[-1]
        rolloff_power = rolloff_ratio * total_power
        rolloff_idx = np.where(cumulative_power >= rolloff_power)[0]
        if len(rolloff_idx) > 0:
            return freqs[rolloff_idx[0]]
        return freqs[-1]

    def _instantaneous_frequency(self, signal_data):
        """计算瞬时频率"""
        analytic_signal = signal.hilbert(signal_data)
        instantaneous_phase = np.unwrap(np.angle(analytic_signal))
        instantaneous_frequency = (np.diff(instantaneous_phase) / (2.0 * np.pi) * self.fs)
        return instantaneous_frequency

    def _time_concentration(self, stft_power):
        """计算时域集中度"""
        time_marginal = np.sum(stft_power, axis=0)
        if np.sum(time_marginal) > 0:
            time_marginal_normalized = time_marginal / np.sum(time_marginal)
            return -np.sum(time_marginal_normalized * np.log(time_marginal_normalized + 1e-12))
        return 0

    def _frequency_concentration(self, stft_power):
        """计算频域集中度"""
        freq_marginal = np.sum(stft_power, axis=1)
        if np.sum(freq_marginal) > 0:
            freq_marginal_normalized = freq_marginal / np.sum(freq_marginal)
            return -np.sum(freq_marginal_normalized * np.log(freq_marginal_normalized + 1e-12))
        return 0

    def _wavelet_features(self, signal_data):
        """计算小波变换特征"""
        # 使用连续小波变换
        widths = np.arange(1, 31)
        cwt_matrix = signal.cwt(signal_data, signal.ricker, widths)

        features = {}
        features['cwt_mean'] = np.mean(np.abs(cwt_matrix))
        features['cwt_std'] = np.std(np.abs(cwt_matrix))
        features['cwt_energy'] = np.sum(np.abs(cwt_matrix) ** 2)
        features['cwt_entropy'] = self._wavelet_entropy(cwt_matrix)

        return features

    def _wavelet_entropy(self, cwt_matrix):
        """计算小波熵"""
        energy_per_scale = np.sum(np.abs(cwt_matrix) ** 2, axis=1)
        total_energy = np.sum(energy_per_scale)
        if total_energy > 0:
            prob = energy_per_scale / total_energy
            prob = prob[prob > 0]  # 避免log(0)
            return -np.sum(prob * np.log(prob))
        return 0

    def extract_all_features(self, signal_data):
        """
        提取所有特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 所有特征的字典
        """
        all_features = {}

        # 时域特征
        time_features = self.time_domain_features(signal_data)
        all_features.update({f'time_{k}': v for k, v in time_features.items()})

        # 频域特征
        freq_features = self.frequency_domain_features(signal_data)
        all_features.update({f'freq_{k}': v for k, v in freq_features.items()})

        # 时频域特征
        time_freq_features = self.time_frequency_features(signal_data)
        all_features.update({f'timefreq_{k}': v for k, v in time_freq_features.items()})

        # 熵特征
        entropy_features = self.entropy_features(signal_data)
        all_features.update({f'entropy_{k}': v for k, v in entropy_features.items()})

        # 分形维数特征
        fractal_features = self.fractal_dimension_features(signal_data)
        all_features.update({f'fractal_{k}': v for k, v in fractal_features.items()})

        return all_features

    def plot_signal_analysis(self, signal_data, title="振动信号分析"):
        """
        绘制信号分析图

        Parameters:
        signal_data: 一维振动信号数组
        title: 图表标题
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(title, fontsize=16)

        # 时域信号
        time_axis = np.arange(len(signal_data)) / self.fs
        axes[0, 0].plot(time_axis, signal_data)
        axes[0, 0].set_title('时域信号')
        axes[0, 0].set_xlabel('时间 (s)')
        axes[0, 0].set_ylabel('幅值')
        axes[0, 0].grid(True)

        # 频域信号
        fft_vals = fft(signal_data)
        freqs = fftfreq(len(signal_data), 1 / self.fs)
        n = len(signal_data) // 2
        axes[0, 1].plot(freqs[:n], np.abs(fft_vals[:n]))
        axes[0, 1].set_title('频域信号')
        axes[0, 1].set_xlabel('频率 (Hz)')
        axes[0, 1].set_ylabel('幅值')
        axes[0, 1].grid(True)

        # STFT时频图
        f, t, Zxx = signal.stft(signal_data, fs=self.fs, nperseg=256)
        axes[1, 0].pcolormesh(t, f, np.abs(Zxx), shading='gouraud')
        axes[1, 0].set_title('STFT时频图')
        axes[1, 0].set_xlabel('时间 (s)')
        axes[1, 0].set_ylabel('频率 (Hz)')

        # 小波变换
        widths = np.arange(1, 31)
        cwt_matrix = signal.cwt(signal_data, signal.ricker, widths)
        axes[1, 1].imshow(np.abs(cwt_matrix), extent=[0, len(signal_data) / self.fs, widths[-1], widths[0]],
                          aspect='auto', cmap='jet')
        axes[1, 1].set_title('连续小波变换')
        axes[1, 1].set_xlabel('时间 (s)')
        axes[1, 1].set_ylabel('尺度')

        plt.tight_layout()
        plt.show()


# 使用示例
def main():
    # 创建特征提取器
    extractor = VibrationFeatureExtractor(sampling_rate=1200)

    # 生成示例振动信号（包含多个频率分量和噪声）
    fs = 1200
    t = np.linspace(0, 2, 2 * fs, endpoint=False)

    # 模拟振动信号：包含50Hz、120Hz、200Hz的谐波分量和随机噪声
    signal_data = (2 * np.sin(2 * np.pi * 50 * t) +
                   1.5 * np.sin(2 * np.pi * 120 * t) +
                   0.8 * np.sin(2 * np.pi * 200 * t) +
                   0.5 * np.random.normal(0, 0.3, len(t)))  # 添加噪声

    # 添加冲击成分（模拟故障）
    impulse_indices = [500, 1200, 1800]
    for idx in impulse_indices:
        if idx < len(signal_data):
            signal_data[idx:idx + 10] += 3 * np.exp(-np.arange(10) * 0.5)

    print("振动信号特征提取结果:")
    print("=" * 50)

    # 提取时域特征
    time_features = extractor.time_domain_features(signal_data)
    print("\n时域特征:")
    for key, value in time_features.items():
        print(f"{key}: {value:.4f}")

    # 提取频域特征
    freq_features = extractor.frequency_domain_features(signal_data)
    print("\n频域特征:")
    for key, value in freq_features.items():
        print(f"{key}: {value:.4f}")

    # 提取时频域特征
    time_freq_features = extractor.time_frequency_features(signal_data)
    print("\n时频域特征:")
    for key, value in time_freq_features.items():
        print(f"{key}: {value:.4f}")

    # 提取熵特征
    entropy_features = extractor.entropy_features(signal_data)
    print("\n熵特征:")
    for key, value in entropy_features.items():
        print(f"{key}: {value:.4f}")

    # 提取分形维数特征
    fractal_features = extractor.fractal_dimension_features(signal_data)
    print("\n分形维数特征:")
    for key, value in fractal_features.items():
        print(f"{key}: {value:.4f}")

    # 提取所有特征
    all_features = extractor.extract_all_features(signal_data)

    # 转换为DataFrame便于查看和保存
    features_df = pd.DataFrame([all_features])
    print(f"\n总共提取了 {len(all_features)} 个特征")
    print("\n特征分类统计:")
    feature_categories = {}
    for key in all_features.keys():
        category = key.split('_')[0]
        if category not in feature_categories:
            feature_categories[category] = 0
        feature_categories[category] += 1

    for category, count in feature_categories.items():
        print(f"{category}: {count} 个特征")

    # 绘制信号分析图
    extractor.plot_signal_analysis(signal_data, "振动信号特征分析")

    return features_df, extractor


if __name__ == "__main__":
    features_df, extractor = main()

    # 显示特征数据框的前几列
    print("\n特征数据框（前10个特征）:")
    print(features_df.iloc[:, :10].T)