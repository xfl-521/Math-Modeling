# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：csv文件数据合并.py
    @时间：2025/9/23 07:43
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import os
import csv
import sys

def main():
    root = 'csv文件/csv文件/1train'                       # 根目录
    out_path = 'All_924-1train.csv'

    # 递归收集所有 csv，按全路径排序
    csv_files = []
    for dirpath, _, files in os.walk(root):
        for f in files:
            if f.lower().endswith('.csv'):
                csv_files.append(os.path.join(dirpath, f))
    csv_files.sort()

    if not csv_files:
        sys.exit('no csv found')

    with open(out_path, 'w', newline='', encoding='utf-8') as fo:
        wo = csv.writer(fo)
        for idx, fp in enumerate(csv_files):
            fname = os.path.basename(fp)        # 只要文件名
            with open(fp, newline='', encoding='utf-8') as fi:
                # 清除fi中的有空值的行
                ri = csv.reader(fi)
                for row in ri:
                    # 检查行中是否有空值（空字符串或只包含空白字符的字符串）
                    if not any(cell.strip() == '' for cell in row):
                        wo.writerow(row)

                header = next(ri, None)
                if header is None:              # 空文件跳过
                    continue

                # 第一份文件：写表头（最前面加 filename）
                if idx == 0:
                    wo.writerow(['filename'] + header)

                # 每行前面加上文件名
                for row in ri:
                    wo.writerow([fname] + row)

    print('done →', out_path)

if __name__ == '__main__':
    main()