# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：分类模型.py
    @时间：2025/9/22 19:20
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, roc_auc_score, roc_curve
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
import warnings

warnings.filterwarnings('ignore')


class VibrationClassifier:
    def __init__(self):
        self.models = {}
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.best_model = None
        self.results = {}

    def load_data(self, train_file=None, test_file=None, X_train=None, y_train=None, X_test=None, y_test=None):
        """
        加载数据 - 支持文件路径或直接传入数据
        """
        if train_file and test_file:
            # 从文件加载
            train_data = pd.read_csv(train_file)
            test_data = pd.read_csv(test_file)

            # 假设最后一列是标签，前面是特征
            self.X_train = train_data.iloc[:, :-1].values
            self.y_train = train_data.iloc[:, -1].values
            self.X_test = test_data.iloc[:, :-1].values
            self.y_test = test_data.iloc[:, -1].values

        else:
            # 直接使用传入的数据
            self.X_train = X_train
            self.y_train = y_train
            self.X_test = X_test
            self.y_test = y_test

        print(f"训练集大小: {self.X_train.shape}")
        print(f"测试集大小: {self.X_test.shape}")
        print(f"特征数量: {self.X_train.shape[1]}")
        print(f"类别分布: {np.unique(self.y_train, return_counts=True)}")

    def preprocess_data(self):
        """
        数据预处理
        """
        # 标准化特征
        self.X_train_scaled = self.scaler.fit_transform(self.X_train)
        self.X_test_scaled = self.scaler.transform(self.X_test)

        # 编码标签（如果是字符串）
        if isinstance(self.y_train[0], str):
            self.y_train_encoded = self.label_encoder.fit_transform(self.y_train)
            self.y_test_encoded = self.label_encoder.transform(self.y_test)
        else:
            self.y_train_encoded = self.y_train
            self.y_test_encoded = self.y_test

        print("数据预处理完成！")

    def initialize_models(self):
        """
        初始化多个机器学习模型
        """
        self.models = {
            'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
            'SVM': SVC(kernel='rbf', random_state=42, probability=True),
            'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
            'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5),
            'Decision Tree': DecisionTreeClassifier(random_state=42),
            'Gradient Boosting': GradientBoostingClassifier(random_state=42),
            'Naive Bayes': GaussianNB()
        }
        print(f"已初始化 {len(self.models)} 个分类模型")

    def train_models(self):
        """
        训练所有模型
        """
        print("开始训练模型...")
        self.trained_models = {}

        for name, model in self.models.items():
            print(f"训练 {name}...")
            model.fit(self.X_train_scaled, self.y_train_encoded)
            self.trained_models[name] = model

            # 训练集结果
            print(f"{name} - 训练集准确率: {accuracy_score(self.y_train_encoded, model.predict(self.X_train_scaled)):.4f}")

            # 交叉验证评估
            cv_scores = cross_val_score(model, self.X_train_scaled, self.y_train_encoded, cv=5)
            print(f"{name} - 交叉验证准确率: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")

    def evaluate_models(self):
        """
        评估所有模型
        """
        print("\n模型评估结果:")
        print("=" * 50)

        self.results = {}

        for name, model in self.trained_models.items():
            # 预测
            y_pred = model.predict(self.X_test_scaled)
            y_pred_proba = model.predict_proba(self.X_test_scaled) if hasattr(model, 'predict_proba') else None

            # 计算指标
            accuracy = accuracy_score(self.y_test_encoded, y_pred)

            # 存储结果
            self.results[name] = {
                'accuracy': accuracy,
                'predictions': y_pred,
                'probabilities': y_pred_proba
            }

            print(f"\n{name}:")
            print(f"准确率: {accuracy:.4f}")
            print("详细分类报告:")
            print(classification_report(self.y_test_encoded, y_pred))

        # 找到最佳模型
        best_model_name = max(self.results.keys(), key=lambda k: self.results[k]['accuracy'])
        self.best_model = self.trained_models[best_model_name]
        self.best_model_name = best_model_name

        print(f"\n最佳模型: {best_model_name}")
        print(f"最佳准确率: {self.results[best_model_name]['accuracy']:.4f}")

    def plot_results(self):
        """
        可视化结果
        """
        # 模型准确率对比
        plt.figure(figsize=(15, 10))

        # 子图1: 准确率对比
        plt.subplot(2, 2, 1)
        model_names = list(self.results.keys())
        accuracies = [self.results[name]['accuracy'] for name in model_names]

        bars = plt.bar(range(len(model_names)), accuracies, color='skyblue', edgecolor='navy', alpha=0.7)
        plt.xlabel('Models')
        plt.ylabel('Accuracy')
        plt.title('Models VS')
        plt.xticks(range(len(model_names)), model_names, rotation=45, ha='right')
        plt.ylim(0, 1)

        # 在柱状图上添加数值
        for bar, acc in zip(bars, accuracies):
            plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                     f'{acc:.3f}', ha='center', va='bottom')

        # 子图2: 最佳模型混淆矩阵
        plt.subplot(2, 2, 2)
        y_pred_best = self.results[self.best_model_name]['predictions']
        cm = confusion_matrix(self.y_test_encoded, y_pred_best)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True)
        plt.title(f'{self.best_model_name} - MC')
        plt.xlabel('Predict')
        plt.ylabel('True')

        # 子图3: 特征重要性（如果最佳模型支持）
        if hasattr(self.best_model, 'feature_importances_'):
            plt.subplot(2, 2, 3)
            importances = self.best_model.feature_importances_
            indices = np.argsort(importances)[::-1]

            # 只显示前10个重要特征
            top_features = min(10, len(importances))
            plt.bar(range(top_features), importances[indices[:top_features]])
            plt.title(f'{self.best_model_name} - 前{top_features}个重要特征')
            plt.xlabel('特征索引')
            plt.ylabel('重要性')
            plt.xticks(range(top_features), [f'特征{i + 1}' for i in indices[:top_features]], rotation=45)

        # 子图4: ROC曲线（二分类情况下）
        if len(np.unique(self.y_test_encoded)) == 2:
            plt.subplot(2, 2, 4)
            for name, result in self.results.items():
                if result['probabilities'] is not None:
                    fpr, tpr, _ = roc_curve(self.y_test_encoded, result['probabilities'][:, 1])
                    auc = roc_auc_score(self.y_test_encoded, result['probabilities'][:, 1])
                    plt.plot(fpr, tpr, label=f'{name} (AUC = {auc:.3f})')

            plt.plot([0, 1], [0, 1], 'k--', label='随机分类')
            plt.xlabel('假正率')
            plt.ylabel('真正率')
            plt.title('ROC曲线')
            plt.legend()
            plt.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def hyperparameter_tuning(self, model_name='Random Forest'):
        """
        超参数调优
        """
        print(f"对 {model_name} 进行超参数调优...")

        if model_name == 'Random Forest':
            param_grid = {
                'n_estimators': [50, 100, 200],
                'max_depth': [None, 10, 20, 30],
                'min_samples_split': [2, 5, 10]
            }
            model = RandomForestClassifier(random_state=42)

        elif model_name == 'SVM':
            param_grid = {
                'C': [0.1, 1, 10, 100],
                'gamma': ['scale', 'auto', 0.001, 0.01, 0.1],
                'kernel': ['rbf', 'poly']
            }
            model = SVC(random_state=42, probability=True)

        elif model_name == 'Gradient Boosting':
            param_grid = {
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7]
            }
            model = GradientBoostingClassifier(random_state=42)

        grid_search = GridSearchCV(model, param_grid, cv=5, scoring='accuracy', n_jobs=-1)
        grid_search.fit(self.X_train_scaled, self.y_train_encoded)

        print(f"最佳参数: {grid_search.best_params_}")
        print(f"最佳交叉验证分数: {grid_search.best_score_:.4f}")

        # 更新模型
        self.trained_models[f'{model_name}_tuned'] = grid_search.best_estimator_

        return grid_search.best_estimator_



def main():
    # 创建分类器实例
    classifier = VibrationClassifier()

    # 示例：生成模拟数据（您需要替换为实际的数据加载）
    print("生成示例数据...")
    np.random.seed(42)
    n_samples_train, n_samples_test = 1000, 200
    n_features = 50
    n_classes = 3

    # 生成训练数据
    X_train = np.random.randn(n_samples_train, n_features)
    # 添加一些类别相关的特征模式
    for i in range(n_classes):
        mask = np.random.choice(n_samples_train, n_samples_train // n_classes, replace=False)
        X_train[mask, :10] += i * 2  # 前10个特征与类别相关
    y_train = np.random.randint(0, n_classes, n_samples_train)

    # 生成测试数据
    X_test = np.random.randn(n_samples_test, n_features)
    for i in range(n_classes):
        mask = np.random.choice(n_samples_test, n_samples_test // n_classes, replace=False)
        X_test[mask, :10] += i * 2
    y_test = np.random.randint(0, n_classes, n_samples_test)

    # 加载数据
    classifier.load_data(X_train=X_train, y_train=y_train, X_test=X_test, y_test=y_test)

    # 数据预处理
    classifier.preprocess_data()

    # 初始化模型
    classifier.initialize_models()

    # 训练模型
    classifier.train_models()

    # 评估模型
    classifier.evaluate_models()

    # 可视化结果
    classifier.plot_results()

    # 超参数调优（可选）
    # print("\n" + "=" * 50)
    # classifier.hyperparameter_tuning('Random Forest')


    print("\n分类任务完成！")

    return classifier


if __name__ == "__main__":
    # 运行主函数
    vibration_classifier = main()

    # 使用说明
    print("\n使用说明:")
    print("1. 将您的数据替换 main() 函数中的示例数据")
    print("2. 数据格式：特征矩阵 + 标签向量")
    print("3. 支持的文件格式：CSV（最后一列为标签）")
    print("4. 可以通过 classifier.load_data(train_file='path/to/train.csv', test_file='path/to/test.csv') 加载文件")
    print("5. 所有模型结果保存在 classifier.results 中")
    print("6. 最佳模型保存在 classifier.best_model 中")