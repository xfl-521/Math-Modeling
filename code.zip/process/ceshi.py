"""
Single-sample CWT scalogram with axes and colorbar
"""
import numpy as np
import matplotlib.pyplot as plt
import pywt
import pandas as pd

# -------------------------------------------------
# 1. 示例数据（1024 点，12 kHz 采样）
# -------------------------------------------------
fs = 12_000
t = np.arange(1024) / fs  # 时间轴 [s]
fr = 35  # 轴转频
fi = 5.9 * fr  # 内圈故障特征频率
signal = (0.7 * np.sin(2 * np.pi * fr * t) +
          1.0 * np.sin(2 * np.pi * fi * t) +
          0.3 * np.sin(2 * np.pi * 2 * fi * t) +
          0.1 * np.random.randn(len(t)))


def time2freq(signal, fs=1060):

    fs = 1060
    t = np.arange(2120) / fs
    wavename = 'morl'
    totalscal = 256
    fc = pywt.central_frequency(wavename)
    scales = (2 * fc * totalscal) / np.arange(totalscal, 0, -1)

    coefficients, frequencies = pywt.cwt(signal, scales, wavename, 1 / fs)
    amp = np.abs(coefficients)

    plt.figure(figsize=(6, 5))
    plt.contourf(t, frequencies, amp, levels=128, cmap='jet')
    plt.colorbar(label='Magnitude')
    plt.title('Time-Frequency Spectrum (CWT)')
    plt.xlabel('Time [s]')
    plt.ylabel('Frequency [Hz]')
    plt.ylim(0, fs / 2)  # 只画奈奎斯特以内
    plt.tight_layout()
    plt.show()




"""
Single-sample STFT spectrogram with axes
"""





import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import stft

def time2freq1(sig, fs):
    """
    单条序列 STFT 时频图（带坐标轴）
    sig : 1-D array-like
    fs  : 采样率
    """
    # 1. 强制转浮点并剔除 NaN/Inf
    sig = np.asarray(sig, dtype=np.float64)
    sig = sig[~np.isnan(sig) & ~np.isinf(sig)]
    if sig.size == 0:
        raise ValueError("输入序列不含有效数值！")

    # 2. STFT
    nper = min(256, sig.size//4)                # 防止序列太短
    f, tt, Zxx = stft(sig, fs=fs, nperseg=nper, noverlap=nper*3//4,
                      window='hann', boundary='zeros')

    # 3. 绘图
    plt.figure(figsize=(6, 5))
    plt.pcolormesh(tt, f, np.abs(Zxx), shading='gouraud', cmap='jet')
    plt.colorbar(label='Magnitude')
    plt.title('Short-Time Fourier Transform')
    plt.xlabel('Time [s]')
    plt.ylabel('Frequency [Hz]')
    plt.ylim(0, fs/2)
    plt.tight_layout()
    plt.show()







data = pd.read_excel("DataALL/B7/12kHz_DE_data_B_0007_B007_0_X118_DE_time.xlsx")
data = data.values
# time2freq(data[0, 3:], fs=1060)
time2freq1(data[0, 3:], fs=1060)

