# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：背景分割.py
    @时间：2025/9/21 10:18
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import cv2 as cv
import numpy as np

img = cv.imread('CT/fj1/1-1.jpg')


gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)


# 横向拼接
img = np.hstack((img, img, img))

# 转为灰度图
# img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)


# 均值滤波
# img = cv.blur(img, (5, 5))
# 中值滤波
img = cv.medianBlur(img, 3)

# 二值化
img = img[:, :, 2]


# 按照10像素的步进将图片进行滑动裁切
# for i in range(0, img.shape[1], 10):
#     img_crop = img[:, i:i+10]
#     cv.imshow('img_crop', img_crop)
#     cv.waitKey(0)
#     if i % 100 == 0:
#         cv.imwrite('img_crop.jpg', img_crop)
#         print('保存成功')

# # 二值化
# ret, thresh = cv.threshold(gray, 160, 255, cv.THRESH_BINARY_INV)
#
cv.imshow('img', img)
# cv.imshow('thresh', thresh)
cv.waitKey(0)
cv.destroyAllWindows()