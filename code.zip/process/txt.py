
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pyts.image import GramianAngularField, MarkovTransitionField
from sklearn.preprocessing import MinMaxScaler
from skimage.feature import graycomatrix, graycoprops


def signal2img(ts, img_size=224, Q=8, plot=False, figsize=(15, 4), titles=None):
    """
    把一维振动信号转成 GASF / GADF / MTF，并可一键画热力图

    参数
    ----
    ts : array-like, shape (T,)
        原始一维序列
    img_size : int or None
        输出图像边长；None 则保持原长
    Q : int, default 8
        MTF 分桶数
    plot : bool, default False
        是否直接弹出热力图
    figsize : tuple
        三子图画布大小
    titles : list of str or None
        三张子图标题，None 则用默认

    返回
    ----
    gasf : ndarray, shape (img_size, img_size)
    gadf : ndarray, shape (img_size, img_size)
    mtf  : ndarray, shape (img_size, img_size)
    """
    ts = np.asarray(ts, dtype=float).ravel()

    # 可选长度对齐
    if img_size is not None and len(ts) != img_size:
        ts = np.interp(np.linspace(0, 1, img_size),
                       np.linspace(0, 1, len(ts)), ts)

    # 归一化 [0,1]
    ts = MinMaxScaler().fit_transform(ts.reshape(-1, 1))[:, 0]

    # 生成图像
    ts_2d = ts.reshape(1, -1)
    gasf = GramianAngularField(method='summation').fit_transform(ts_2d)[0]
    gadf = GramianAngularField(method='difference').fit_transform(ts_2d)[0]
    mtf = MarkovTransitionField(n_bins=Q).fit_transform(ts_2d)[0]

    # 可视化
    if plot:
        if titles is None:
            titles = ['GASF', 'GADF', 'MTF']
        sns.set_style("white")
        fig, ax = plt.subplots(1, 3, figsize=figsize)
        for a, mat, title in zip(ax, [gasf, gadf, mtf], titles):
            sns.heatmap(mat, cmap='jet', ax=a, cbar=True,
                        xticklabels=False, yticklabels=False)
            a.set_title(title)
        plt.tight_layout()
        plt.show()

    return gasf, gadf, mtf


def glcm_features(img, distances=None, angles=None, levels=256, symmetric=True, normed=True):
    """
    计算单张图像的 GLCM 及 8 个纹理特征

    参数
    ----
    img : ndarray
        2-D 图像，值域 [0,1] 或 [0,255] 均可
    distances : list, default [1]
        像素间距
    angles : list, default [0, π/4, π/2, 3π/4]
        方向（弧度）
    levels : int, default 256
        灰度级量化层数
    symmetric / normed : bool
        是否对称、归一化 GLCM

    返回
    ----
    glcm : ndarray, shape (len(distances), len(angles), levels, levels)
    features : dict
        8 个纹理特征，键见下
    """
    if distances is None:
        distances = [1]
    if angles is None:
        angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]

    # 0–1 → 0–255 量化
    img = (img * (levels-1)).astype(np.uint8)

    glcm = graycomatrix(img,
                        distances=distances,
                        angles=angles,
                        levels=levels,
                        symmetric=symmetric,
                        normed=normed)

    # 把 4 个方向平均，得到旋转不变特征（可选）
    glcm_mean = glcm.mean(axis=3, keepdims=True)   # 平均角度
    glcm_mean = glcm_mean.mean(axis=2, keepdims=True)  # 平均距离（如只需整体特征）

    # 8 个经典特征
    features = {
        'contrast'     : graycoprops(glcm, 'contrast').mean(),
        'dissimilarity': graycoprops(glcm, 'dissimilarity').mean(),
        'homogeneity'  : graycoprops(glcm, 'homogeneity').mean(),
        'energy'       : graycoprops(glcm, 'energy').mean(),
        'correlation'  : graycoprops(glcm, 'correlation').mean(),
        'ASM'          : graycoprops(glcm, 'ASM').mean(),
        'entropy'      : -np.sum(glcm*np.log2(glcm+1e-12)),  # 手动算熵
        'auto_correlation': graycoprops(glcm, 'correlation').mean()  # 同 correlation
    }
    return glcm, features

def signal_glcm_features(signal_data):
    # 先转图像
    gasf_img, gadf_img, mtf_img = signal2img(signal_data, img_size=224, plot=False)
    # 再提特征
    _, features1 = glcm_features(gasf_img)
    _, features2 = glcm_features(gadf_img)
    _, features3 = glcm_features(mtf_img)
    keya = list(features1.keys())
    values1 = [features1[key] for key in keya]
    values2 = [features2[key] for key in keya]
    values3 = [features3[key] for key in keya]
    features = [values1, values2, values3]
    features = np.array(features)
    features = features.flatten()

    return features



# ---------------- 使用示例 ----------------
if __name__ == "__main__":

    path = '1'
    for file in os.listdir(path):
        if file.endswith('.xlsx'):
            file_path = os.path.join(path, file)

            # 读取数据，不读第一行
            data = pd.read_excel(file_path)
            # 裁切数据
            info = data.iloc[1:, :3]
            value = data.iloc[1:, 3:].values

            feature_all = []
            for i in range(value.shape[0]):
                sensor = value[i]
                # 绘制图
                # plt.plot(sensor)
                # plt.show()
                gasf_img, gadf_img, mtf_img = signal2img(sensor, img_size=224, plot=False)

                # GLCM
                _, features1 = glcm_features(gasf_img)
                _, features2 = glcm_features(gadf_img)
                _, features3 = glcm_features(mtf_img)

                keya = list(features1.keys())
                print(keya)
                # 提取值列表
                values1 = [features1[key] for key in keya]
                values2 = [features2[key] for key in keya]
                values3 = [features3[key] for key in keya]
                # 将三个列表进行拼接
                features = [values1, values2, values3]

                features = np.array(features)

                # 展平
                features = features.flatten().tolist()
                # 转为列表
                # features = list(features)

                feature_all.append(features)

            feature_all = np.array(feature_all)
            features_all = pd.DataFrame(feature_all)





            data = pd.read_csv(file_path)
            data = data.values
            data = data.T
            data = savgol_filter()
