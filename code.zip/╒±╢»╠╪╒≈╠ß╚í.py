# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：振动特征提取.py
    @时间：2025/9/21 22:17
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import numpy as np
import os
import pandas as pd
from scipy import signal, stats
from scipy.fft import fft, fftfreq
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import warnings
import openpyxl

warnings.filterwarnings('ignore')


class VibrationFeatureExtractor:
    """振动信号特征提取器"""

    def __init__(self, sampling_rate=1000):
        """
        初始化特征提取器

        Parameters:
        sampling_rate: 采样频率 (Hz)
        """
        self.fs = sampling_rate

    def time_domain_features(self, signal_data):
        """
        提取时域特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 时域特征字典
        """
        features = {}

        # 基础统计特征
        features['mean'] = np.mean(signal_data)  # 均值
        features['std'] = np.std(signal_data)  # 标准差
        features['var'] = np.var(signal_data)  # 方差
        features['rms'] = np.sqrt(np.mean(signal_data ** 2))  # 均方根值

        # 峰值特征
        features['max'] = np.max(signal_data)  # 最大值
        features['min'] = np.min(signal_data)  # 最小值
        features['peak_to_peak'] = features['max'] - features['min']  # 峰峰值
        features['peak'] = max(abs(features['max']), abs(features['min']))  # 峰值

        # 形状特征
        features['skewness'] = stats.skew(signal_data)  # 偏度
        features['kurtosis'] = stats.kurtosis(signal_data)  # 峭度

        # 脉冲指标
        if features['mean'] != 0:
            features['crest_factor'] = features['peak'] / features['rms']  # 波峰因子
            features['clearance_factor'] = features['peak'] / (np.mean(np.sqrt(np.abs(signal_data)))) ** 2  # 裕度因子
            features['shape_factor'] = features['rms'] / np.mean(np.abs(signal_data))  # 波形因子
            features['impulse_factor'] = features['peak'] / np.mean(np.abs(signal_data))  # 脉冲因子
        else:
            features['crest_factor'] = 0
            features['clearance_factor'] = 0
            features['shape_factor'] = 0
            features['impulse_factor'] = 0

        # 能量特征
        features['energy'] = np.sum(signal_data ** 2)  # 信号能量
        features['power'] = features['energy'] / len(signal_data)  # 平均功率

        return features

    def frequency_domain_features(self, signal_data):
        """
        提取频域特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 频域特征字典
        """
        features = {}

        # 计算FFT
        fft_vals = fft(signal_data)
        freqs = fftfreq(len(signal_data), 1 / self.fs)

        # 只取正频率部分
        n = len(signal_data) // 2
        freqs = freqs[:n]
        fft_magnitude = np.abs(fft_vals[:n])
        fft_power = fft_magnitude ** 2

        # 频域基础特征
        features['spectral_centroid'] = np.sum(freqs * fft_power) / np.sum(fft_power)  # 频谱重心
        features['spectral_spread'] = np.sqrt(np.sum(((freqs - features['spectral_centroid']) ** 2) * fft_power) / np.sum(fft_power))  # 频谱扩展度
        features['spectral_rolloff'] = self._spectral_rolloff(freqs, fft_power, 0.85)  # 频谱滚降点
        features['spectral_flux'] = np.sum(np.diff(fft_magnitude) ** 2)  # 频谱流量

        # 主频特征
        dominant_freq_idx = np.argmax(fft_magnitude)
        features['dominant_frequency'] = freqs[dominant_freq_idx]  # 主频
        features['dominant_magnitude'] = fft_magnitude[dominant_freq_idx]  # 主频幅值

        # 频带能量特征
        features['total_power'] = np.sum(fft_power)  # 总功率

        # 定义频带范围
        low_freq_mask = (freqs >= 0) & (freqs < self.fs / 8)
        mid_freq_mask = (freqs >= self.fs / 8) & (freqs < self.fs / 4)
        high_freq_mask = (freqs >= self.fs / 4) & (freqs < self.fs / 2)

        features['low_freq_power'] = np.sum(fft_power[low_freq_mask])  # 低频功率
        features['mid_freq_power'] = np.sum(fft_power[mid_freq_mask])  # 中频功率
        features['high_freq_power'] = np.sum(fft_power[high_freq_mask])  # 高频功率

        # 频率分布特征
        if features['total_power'] > 0:
            features['low_freq_ratio'] = features['low_freq_power'] / features['total_power']
            features['mid_freq_ratio'] = features['mid_freq_power'] / features['total_power']
            features['high_freq_ratio'] = features['high_freq_power'] / features['total_power']
        else:
            features['low_freq_ratio'] = 0
            features['mid_freq_ratio'] = 0
            features['high_freq_ratio'] = 0

        # 频谱峭度和偏度
        features['spectral_kurtosis'] = stats.kurtosis(fft_magnitude)
        features['spectral_skewness'] = stats.skew(fft_magnitude)

        return features

    def time_frequency_features(self, signal_data, nperseg=256):
        """
        提取时频域特征

        Parameters:
        signal_data: 一维振动信号数组
        nperseg: STFT窗口长度

        Returns:
        dict: 时频域特征字典
        """
        features = {}

        # 短时傅里叶变换 (STFT)
        f, t, Zxx = signal.stft(signal_data, fs=self.fs, nperseg=nperseg)
        stft_magnitude = np.abs(Zxx)
        stft_power = stft_magnitude ** 2

        # 时频域基础特征
        features['stft_mean'] = np.mean(stft_magnitude)  # STFT幅值均值
        features['stft_std'] = np.std(stft_magnitude)  # STFT幅值标准差
        features['stft_max'] = np.max(stft_magnitude)  # STFT最大幅值
        features['stft_energy'] = np.sum(stft_power)  # STFT总能量

        # 瞬时频率特征
        instantaneous_freq = self._instantaneous_frequency(signal_data)
        features['inst_freq_mean'] = np.mean(instantaneous_freq)  # 瞬时频率均值
        features['inst_freq_std'] = np.std(instantaneous_freq)  # 瞬时频率标准差
        features['inst_freq_range'] = np.ptp(instantaneous_freq)  # 瞬时频率范围

        # 时频集中度
        features['time_concentration'] = self._time_concentration(stft_power)
        features['freq_concentration'] = self._frequency_concentration(stft_power)

        # 小波变换特征
        wavelet_features = self._wavelet_features(signal_data)
        features.update(wavelet_features)

        return features

    def _spectral_rolloff(self, freqs, power, rolloff_ratio=0.85):
        """计算频谱滚降点"""
        cumulative_power = np.cumsum(power)
        total_power = cumulative_power[-1]
        rolloff_power = rolloff_ratio * total_power
        rolloff_idx = np.where(cumulative_power >= rolloff_power)[0]
        if len(rolloff_idx) > 0:
            return freqs[rolloff_idx[0]]
        return freqs[-1]

    def _instantaneous_frequency(self, signal_data):
        """计算瞬时频率"""
        analytic_signal = signal.hilbert(signal_data)
        instantaneous_phase = np.unwrap(np.angle(analytic_signal))
        instantaneous_frequency = (np.diff(instantaneous_phase) / (2.0 * np.pi) * self.fs)
        return instantaneous_frequency

    def _time_concentration(self, stft_power):
        """计算时域集中度"""
        time_marginal = np.sum(stft_power, axis=0)
        if np.sum(time_marginal) > 0:
            time_marginal_normalized = time_marginal / np.sum(time_marginal)
            return -np.sum(time_marginal_normalized * np.log(time_marginal_normalized + 1e-12))
        return 0

    def _frequency_concentration(self, stft_power):
        """计算频域集中度"""
        freq_marginal = np.sum(stft_power, axis=1)
        if np.sum(freq_marginal) > 0:
            freq_marginal_normalized = freq_marginal / np.sum(freq_marginal)
            return -np.sum(freq_marginal_normalized * np.log(freq_marginal_normalized + 1e-12))
        return 0

    def _wavelet_features(self, signal_data):
        """计算小波变换特征"""
        # 使用连续小波变换
        widths = np.arange(1, 31)
        cwt_matrix = signal.cwt(signal_data, signal.ricker, widths)

        features = {}
        features['cwt_mean'] = np.mean(np.abs(cwt_matrix))
        features['cwt_std'] = np.std(np.abs(cwt_matrix))
        features['cwt_energy'] = np.sum(np.abs(cwt_matrix) ** 2)
        features['cwt_entropy'] = self._wavelet_entropy(cwt_matrix)

        return features

    def _wavelet_entropy(self, cwt_matrix):
        """计算小波熵"""
        energy_per_scale = np.sum(np.abs(cwt_matrix) ** 2, axis=1)
        total_energy = np.sum(energy_per_scale)
        if total_energy > 0:
            prob = energy_per_scale / total_energy
            prob = prob[prob > 0]  # 避免log(0)
            return -np.sum(prob * np.log(prob))
        return 0

    # 转为格拉姆角和场图提取特征
    def generate_GASF(self, sensor, image_size=224):
        from pyts.image import GramianAngularField
        from sklearn.preprocessing import MinMaxScaler

        # 数据标准化到[-1,1]
        scaler = MinMaxScaler(feature_range=(-1, 1))
        sensor_norm = scaler.fit_transform(sensor.T).T

        # 创建GAF转换器
        gasf = GramianAngularField(image_size=image_size, method='summation')

        # 生成所有传感器的GASF图像
        img = gasf.fit_transform(sensor_norm)[0]  # 输入需要是2D数组

        return img

    def generate_GADF(self, sensor, image_size=224):
        from pyts.image import GramianAngularField
        from sklearn.preprocessing import MinMaxScaler

        # 数据标准化到[-1,1]
        scaler = MinMaxScaler(feature_range=(-1, 1))
        sensor_norm = scaler.fit_transform(sensor.T).T

        # 创建GAF转换器
        gadf = GramianAngularField(image_size=image_size, method='difference')

        # 生成所有传感器的GADF图像
        img = gadf.fit_transform(sensor_norm[i:i + 1])[0]  # 输入需要是2D数组

        return img

    def generate_MTF(self, sensor, image_size=224, n_bins=8):
        from pyts.image import MarkovTransitionField

        # 创建MTF转换器（自动包含分箱离散化）
        mtf = MarkovTransitionField(image_size=image_size, n_bins=n_bins)

        # 生成所有传感器的MTF图像
        img = mtf.fit_transform(sensor)[0]  # 输入需要是2D数组

        return img



    def extract_all_features(self, signal_data):
        """
        提取所有特征

        Parameters:
        signal_data: 一维振动信号数组

        Returns:
        dict: 所有特征的字典
        """
        all_features = {}

        # 时域特征
        time_features = self.time_domain_features(signal_data)
        all_features.update({f'time_{k}': v for k, v in time_features.items()})


        # 频域特征
        freq_features = self.frequency_domain_features(signal_data)
        all_features.update({f'freq_{k}': v for k, v in freq_features.items()})

        # 时频域特征
        time_freq_features = self.time_frequency_features(signal_data)
        all_features.update({f'timefreq_{k}': v for k, v in time_freq_features.items()})

        return all_features

    def plot_signal_analysis(self, signal_data, title="振动信号分析"):
        """
        绘制信号分析图

        Parameters:
        signal_data: 一维振动信号数组
        title: 图表标题
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(title, fontsize=16)

        # 时域信号
        time_axis = np.arange(len(signal_data)) / self.fs
        axes[0, 0].plot(time_axis, signal_data)
        axes[0, 0].set_title('时域信号')
        axes[0, 0].set_xlabel('时间 (s)')
        axes[0, 0].set_ylabel('幅值')
        axes[0, 0].grid(True)

        # 频域信号
        fft_vals = fft(signal_data)
        freqs = fftfreq(len(signal_data), 1 / self.fs)
        n = len(signal_data) // 2
        axes[0, 1].plot(freqs[:n], np.abs(fft_vals[:n]))
        axes[0, 1].set_title('频域信号')
        axes[0, 1].set_xlabel('频率 (Hz)')
        axes[0, 1].set_ylabel('幅值')
        axes[0, 1].grid(True)

        # STFT时频图
        f, t, Zxx = signal.stft(signal_data, fs=self.fs, nperseg=256)
        axes[1, 0].pcolormesh(t, f, np.abs(Zxx), shading='gouraud')
        axes[1, 0].set_title('STFT时频图')
        axes[1, 0].set_xlabel('时间 (s)')
        axes[1, 0].set_ylabel('频率 (Hz)')

        # 小波变换
        widths = np.arange(1, 31)
        cwt_matrix = signal.cwt(signal_data, signal.ricker, widths)
        axes[1, 1].imshow(np.abs(cwt_matrix), extent=[0, len(signal_data) / self.fs, widths[-1], widths[0]],
                          aspect='auto', cmap='jet')
        axes[1, 1].set_title('连续小波变换')
        axes[1, 1].set_xlabel('时间 (s)')
        axes[1, 1].set_ylabel('尺度')

        plt.tight_layout()
        plt.show()


import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pyts.image import GramianAngularField, MarkovTransitionField
from sklearn.preprocessing import MinMaxScaler
from skimage.feature import graycomatrix, graycoprops


def signal2img(ts, img_size=224, Q=8, plot=False, figsize=(15, 4), titles=None):
    """
    把一维振动信号转成 GASF / GADF / MTF，并可一键画热力图

    参数
    ----
    ts : array-like, shape (T,)
        原始一维序列
    img_size : int or None
        输出图像边长；None 则保持原长
    Q : int, default 8
        MTF 分桶数
    plot : bool, default False
        是否直接弹出热力图
    figsize : tuple
        三子图画布大小
    titles : list of str or None
        三张子图标题，None 则用默认

    返回
    ----
    gasf : ndarray, shape (img_size, img_size)
    gadf : ndarray, shape (img_size, img_size)
    mtf  : ndarray, shape (img_size, img_size)
    """
    ts = np.asarray(ts, dtype=float).ravel()

    # 可选长度对齐
    if img_size is not None and len(ts) != img_size:
        ts = np.interp(np.linspace(0, 1, img_size),
                       np.linspace(0, 1, len(ts)), ts)

    # 归一化 [0,1]
    ts = MinMaxScaler().fit_transform(ts.reshape(-1, 1))[:, 0]

    # 生成图像
    ts_2d = ts.reshape(1, -1)
    gasf = GramianAngularField(method='summation').fit_transform(ts_2d)[0]
    gadf = GramianAngularField(method='difference').fit_transform(ts_2d)[0]
    mtf = MarkovTransitionField(n_bins=Q).fit_transform(ts_2d)[0]

    # 可视化
    if plot:
        if titles is None:
            titles = ['GASF', 'GADF', 'MTF']
        sns.set_style("white")
        fig, ax = plt.subplots(1, 3, figsize=figsize)
        for a, mat, title in zip(ax, [gasf, gadf, mtf], titles):
            sns.heatmap(mat, cmap='jet', ax=a, cbar=True,
                        xticklabels=False, yticklabels=False)
            a.set_title(title)
        plt.tight_layout()
        plt.show()

    return gasf, gadf, mtf


def glcm_features(img, distances=None, angles=None, levels=256, symmetric=True, normed=True):
    """
    计算单张图像的 GLCM 及 8 个纹理特征

    参数
    ----
    img : ndarray
        2-D 图像，值域 [0,1] 或 [0,255] 均可
    distances : list, default [1]
        像素间距
    angles : list, default [0, π/4, π/2, 3π/4]
        方向（弧度）
    levels : int, default 256
        灰度级量化层数
    symmetric / normed : bool
        是否对称、归一化 GLCM

    返回
    ----
    glcm : ndarray, shape (len(distances), len(angles), levels, levels)
    features : dict
        8 个纹理特征，键见下
    """
    if distances is None:
        distances = [1]
    if angles is None:
        angles = [0, np.pi / 4, np.pi / 2, 3 * np.pi / 4]

    # 0–1 → 0–255 量化
    img = (img * (levels - 1)).astype(np.uint8)

    glcm = graycomatrix(img,
                        distances=distances,
                        angles=angles,
                        levels=levels,
                        symmetric=symmetric,
                        normed=normed)

    # 把 4 个方向平均，得到旋转不变特征（可选）
    glcm_mean = glcm.mean(axis=3, keepdims=True)  # 平均角度
    glcm_mean = glcm_mean.mean(axis=2, keepdims=True)  # 平均距离（如只需整体特征）

    # 8 个经典特征
    features = {
        'contrast': graycoprops(glcm, 'contrast').mean(),
        'dissimilarity': graycoprops(glcm, 'dissimilarity').mean(),
        'homogeneity': graycoprops(glcm, 'homogeneity').mean(),
        'energy': graycoprops(glcm, 'energy').mean(),
        'correlation': graycoprops(glcm, 'correlation').mean(),
        'ASM': graycoprops(glcm, 'ASM').mean(),
        'entropy': -np.sum(glcm * np.log2(glcm + 1e-12)),  # 手动算熵
        'auto_correlation': graycoprops(glcm, 'correlation').mean()  # 同 correlation
    }
    return glcm, features


def signal_glcm_features(signal_data):
    # 先转图像
    gasf_img, gadf_img, mtf_img = signal2img(signal_data, img_size=224, plot=False)
    # 将三个图像拼接成三通道
    img = np.dstack([gasf_img, gadf_img, mtf_img])
    # 再提特征
    _, features1 = glcm_features(gasf_img)
    _, features2 = glcm_features(gadf_img)
    _, features3 = glcm_features(mtf_img)
    keya = list(features1.keys())
    values1 = [features1[key] for key in keya]
    values2 = [features2[key] for key in keya]
    values3 = [features3[key] for key in keya]
    features = [values1, values2, values3]
    features = np.array(features)
    features = features.flatten().tolist()

    return features, img

def time2freq(x: np.ndarray,
              fs: float):
    """
    把一维振动时域信号转成频域结果。

    参数
    ----
    x : 1-D ndarray
        时域采样序列（任意长度，自动拷贝）。
    fs : float
        采样频率 [Hz]。
    window : str, optional
        Welch 法所用窗函数，默认 'hann'。
    nperseg : int, optional
        每段长度，默认 None 表示 256 或更小的 2 的幂。
    noverlap : int, optional
        段间重叠点数，默认 None 表示 nperseg//2。

    返回
    ----
    freq : 1-D ndarray
        频率轴 [Hz]，范围 0 … fs/2。
    amp_spec : 1-D ndarray
        单侧幅值谱（已归一化，与原始信号单位一致）。
    psd : 1-D ndarray
        功率谱密度 [V²/Hz]（或原始单位²/Hz）。
    """
    x = np.asarray(x, dtype=float).ravel()
    N = x.size

    # ---- 1. 快速傅里叶幅值谱（单侧） ----
    N_fft = 1 << int(np.ceil(np.log2(N)))      # 向上取 2 的幂，提速
    X_fft = np.fft.fft(x, n=N_fft)
    freq_full = np.fft.fftfreq(N_fft, d=1/fs)
    half = N_fft // 2
    freq = freq_full[:half]

    amp_spec = np.abs(X_fft)[:half]
    amp_spec[1:] *= 2 / N          # 归一化，除直流
    amp_spec[0] /= N

    return amp_spec


# 使用示例
def main():
    # 创建特征提取器
    extractor = VibrationFeatureExtractor(sampling_rate=1200)

    path = 'target'
    output_path = 'F:/Mathmodel_Data/924/target_Feature'
    os.makedirs(output_path, exist_ok=True)

    # 遍历文件夹下子文件夹中的所有文件

    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith('.xlsx'):
                file_path = os.path.join(root, file)
                print(file)
                print(root)
                # 读取数据，不读第一行
                data = pd.read_excel(file_path)
                # 裁切数据
                info = data.iloc[1:, :3]
                value = data.iloc[1:, 3:].values
                featture_all = []

                # 计算安全起始/结束索引
                n_seg = value.shape[0]  # 或者 len(value)
                start = 50 if n_seg > 50 else 0
                end = min(101, n_seg)  # 防止上限也超

                for i in range(0, n_seg):

                    signal_data = value[i]
                    features = extractor.extract_all_features(signal_data)
                    # 提取key列表
                    keys = list(features.keys())
                    features = list(features[k] for k in keys)
                    glcm_features1, img1 = signal_glcm_features(signal_data)
                    signal_data = time2freq(signal_data, fs=2120)
                    glcm_features2, img2 = signal_glcm_features(signal_data)

                    # 沿着通道维度拼接
                    # img_npy = np.dstack([img1, img2])
                    # # 保存为npy文件
                    # cls = root[9:]
                    # # print(cls)
                    # # np.save(os.path.join(output_path, str(cls) + file[:-4] + '_' + str(i) + '.npy'), img_npy)

                    # 将特征转为列表
                    features.extend(glcm_features1)
                    features.extend(glcm_features2)
                    featture_all.append(features)

                featture_all = np.array(featture_all).astype(np.float32)

                features_all = pd.DataFrame(featture_all)
                # 将inof插入
                features_all = pd.concat([info, features_all], axis=1)
                features_all.to_csv(os.path.join(output_path, file[:-4] + '.csv'), index=False)


    # # 生成示例振动信号（包含多个频率分量和噪声）
    # fs = 1000
    # t = np.linspace(0, 2, 2 * fs, endpoint=False)
    #
    # # 模拟振动信号：包含50Hz、120Hz、200Hz的谐波分量和随机噪声
    # signal_data = (2 * np.sin(2 * np.pi * 50 * t) +
    #                1.5 * np.sin(2 * np.pi * 120 * t) +
    #                0.8 * np.sin(2 * np.pi * 200 * t) +
    #                0.5 * np.random.normal(0, 0.3, len(t)))  # 添加噪声
    #
    # # 添加冲击成分（模拟故障）
    # impulse_indices = [500, 1200, 1800]
    # for idx in impulse_indices:
    #     if idx < len(signal_data):
    #         signal_data[idx:idx + 10] += 3 * np.exp(-np.arange(10) * 0.5)
    #
    # print("振动信号特征提取结果:")
    # print("=" * 50)
    #
    # # 提取时域特征
    # time_features = extractor.time_domain_features(signal_data)
    # print("\n时域特征:")
    # for key, value in time_features.items():
    #     print(f"{key}: {value:.4f}")
    #
    # # 提取频域特征
    # freq_features = extractor.frequency_domain_features(signal_data)
    # print("\n频域特征:")
    # for key, value in freq_features.items():
    #     print(f"{key}: {value:.4f}")
    #
    # # 提取时频域特征
    # time_freq_features = extractor.time_frequency_features(signal_data)
    # print("\n时频域特征:")
    # for key, value in time_freq_features.items():
    #     print(f"{key}: {value:.4f}")

    # 提取所有特征
    # all_features = extractor.extract_all_features(signal_data)
    #
    # # 转换为DataFrame便于查看和保存
    # features_df = pd.DataFrame([all_features])
    # print(f"\n总共提取了 {len(all_features)} 个特征")
    #
    # # 绘制信号分析图
    # extractor.plot_signal_analysis(signal_data, "振动信号特征分析")
    #
    # return features_df, extractor


if __name__ == "__main__":
    # features_df, extractor = main()
    #
    # # 显示特征数据框的前几列
    # print("\n特征数据框（前10个特征）:")
    # print(features_df.iloc[:, :10].T)
    main()