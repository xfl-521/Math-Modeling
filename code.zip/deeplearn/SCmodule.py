# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：SCmodule.py
    @时间：2025/9/23 18:25
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------------- 一维 GroupBatchNorm -------------------
class GroupBatchnorm1d(nn.Module):
    def __init__(self, c_num: int, group_num: int = 16, eps: float = 1e-10):
        super().__init__()
        assert c_num >= group_num
        self.group_num = group_num
        self.weight = nn.Parameter(torch.randn(c_num, 1))
        self.bias   = nn.Parameter(torch.zeros(c_num, 1))
        self.eps    = eps

    def forward(self, x):
        # x: (B, C, L)
        b, c, l = x.shape
        x = x.view(b, self.group_num, -1)          # (B, G, -1)
        mean = x.mean(dim=2, keepdim=True)
        std  = x.std (dim=2, keepdim=True)
        x = (x - mean) / (std + self.eps)
        x = x.view(b, c, l)
        return x * self.weight + self.bias


# ------------------- 一维 SRU -------------------
class SRU1d(nn.Module):
    def __init__(self,
                 oup_channels: int,
                 group_num: int = 16,
                 gate_threshold: float = 0.5,
                 torch_gn: bool = True):
        super().__init__()
        if torch_gn:
            self.gn = nn.GroupNorm(num_groups=group_num, num_channels=oup_channels)
        else:
            self.gn = GroupBatchnorm1d(c_num=oup_channels, group_num=group_num)
        self.gate_threshold = gate_threshold
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        gn_x    = self.gn(x)                                   # (B, C, L)
        w_gamma = (self.gn.weight / self.gn.weight.sum()).view(1, -1, 1)
        reweigts = self.sigmoid(gn_x * w_gamma)                # (B, C, L)
        w1 = torch.where(reweigts > self.gate_threshold,
                         torch.ones_like(reweigts), reweigts)
        w2 = torch.where(reweigts > self.gate_threshold,
                         torch.zeros_like(reweigts), reweigts)
        x1, x2 = w1 * x, w2 * x
        return self.reconstruct(x1, x2)

    def reconstruct(self, x1, x2):
        x11, x12 = torch.chunk(x1, 2, dim=1)
        x21, x22 = torch.chunk(x2, 2, dim=1)
        return torch.cat([x11 + x22, x12 + x21], dim=1)


# ------------------- 一维 CRU -------------------
class CRU1d(nn.Module):
    def __init__(self,
                 op_channel: int,
                 alpha: float = 0.5,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3):
        super().__init__()
        up_channel  = int(alpha * op_channel)
        low_channel = op_channel - up_channel
        self.up_channel, self.low_channel = up_channel, low_channel

        self.squeeze1 = nn.Conv1d(up_channel,  up_channel  // squeeze_radio, 1, bias=False)
        self.squeeze2 = nn.Conv1d(low_channel, low_channel // squeeze_radio, 1, bias=False)

        # up branch
        self.GWC = nn.Conv1d(up_channel // squeeze_radio, op_channel,
                             kernel_size=group_kernel_size, padding=group_kernel_size//2,
                             groups=group_size, bias=False)
        self.PWC1 = nn.Conv1d(up_channel // squeeze_radio, op_channel, 1, bias=False)

        # low branch
        self.PWC2 = nn.Conv1d(low_channel // squeeze_radio,
                              op_channel - low_channel // squeeze_radio, 1, bias=False)
        self.advavg = nn.AdaptiveAvgPool1d(1)

    def forward(self, x):
        up, low = torch.split(x, [self.up_channel, self.low_channel], dim=1)

        up, low = self.squeeze1(up), self.squeeze2(low)

        Y1 = self.GWC(up) + self.PWC1(up)
        Y2 = torch.cat([self.PWC2(low), low], dim=1)

        out = torch.cat([Y1, Y2], dim=1)
        att = F.softmax(self.advavg(out), dim=1)   # (B, C, 1)
        out = att * out
        out1, out2 = torch.chunk(out, 2, dim=1)
        return out1 + out2


# ------------------- 一维 ScConv -------------------
class ScConv1d(nn.Module):
    def __init__(self,
                 op_channel: int,
                 group_num: int = 16,
                 gate_threshold: float = 0.5,
                 alpha: float = 0.5,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3):
        super().__init__()
        self.SRU = SRU1d(op_channel,
                         group_num=group_num,
                         gate_threshold=gate_threshold)
        self.CRU = CRU1d(op_channel,
                         alpha=alpha,
                         squeeze_radio=squeeze_radio,
                         group_size=group_size,
                         group_kernel_size=group_kernel_size)

    def forward(self, x):
        x = self.SRU(x)
        x = self.CRU(x)
        return x


# ------------------- 简单测试 -------------------
if __name__ == '__main__':
    x = torch.randn(2, 64, 128)   # (B, C, L)
    model = ScConv1d(64)
    print(model(x).shape)         # → torch.Size([2, 64, 128])