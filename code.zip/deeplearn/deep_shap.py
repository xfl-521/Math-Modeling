import torch
import numpy as np
import matplotlib.pyplot as plt
import shap
from sklearn.metrics import confusion_matrix
import seaborn as sns
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
import warnings

warnings.filterwarnings('ignore')

# 设置中文字体显示
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def prepare_shap_data(test_loader, num_samples=100):
    """
    准备SHAP分析所需的数据

    Args:
        test_loader: 测试数据加载器
        num_samples: 用于SHAP分析的样本数量

    Returns:
        background_data: 背景数据集
        test_data: 测试数据
        test_labels: 测试标签
    """
    # 从测试集中提取数据
    all_data = []
    all_labels = []

    for data, labels in test_loader:
        all_data.append(data.numpy())
        all_labels.append(labels.numpy())

    all_data = np.vstack(all_data)
    all_labels = np.concatenate(all_labels)

    print(f"原始数据形状: {all_data.shape}")

    # 处理数据维度 - 如果是3维的(batch_size, channels, length)，需要重塑
    if len(all_data.shape) == 3:
        if all_data.shape[1] == 1:
            # 如果中间维度是1，则压缩掉
            all_data = all_data.squeeze(1)  # (batch_size, length)
            print(f"压缩后数据形状: {all_data.shape}")
        else:
            # 如果有多个通道，展平为2D
            batch_size = all_data.shape[0]
            all_data = all_data.reshape(batch_size, -1)
            print(f"展平后数据形状: {all_data.shape}")

    # 随机选择样本用于SHAP分析
    if len(all_data) > num_samples:
        indices = np.random.choice(len(all_data), num_samples, replace=False)
        background_data = all_data[indices]
        background_labels = all_labels[indices]
    else:
        background_data = all_data
        background_labels = all_labels

    # 选择前50个样本作为背景数据，后50个作为解释样本
    mid_point = len(background_data) // 2
    background_set = background_data[:mid_point]
    test_set = background_data[mid_point:]
    test_set_labels = background_labels[mid_point:]

    return background_set, test_set, test_set_labels


def create_model_wrapper(model, device):
    """
    创建模型包装器，用于SHAP分析

    Args:
        model: PyTorch模型
        device: 设备

    Returns:
        wrapper函数
    """

    def model_wrapper(x):
        # 将numpy数组转换为tensor
        if isinstance(x, np.ndarray):
            # 确保输入数据有正确的维度
            if len(x.shape) == 2:
                # 如果是2D数据，需要添加channel维度
                x = x[:, np.newaxis, :]  # (batch_size, 1, length)
            x = torch.FloatTensor(x).to(device)

        model.eval()
        with torch.no_grad():
            outputs = model(x)
            # 返回softmax概率
            probabilities = torch.softmax(outputs, dim=1)
            return probabilities.cpu().numpy()

    return model_wrapper


def shap_deep_explainer_analysis(model, background_data, test_data, device, class_names=None):
    """
    使用SHAP DeepExplainer进行可解释性分析

    Args:
        model: PyTorch模型
        background_data: 背景数据
        test_data: 测试数据
        device: 设备
        class_names: 类别名称

    Returns:
        explainer: SHAP解释器
        shap_values: SHAP值
    """
    print("正在初始化SHAP DeepExplainer...")

    # 准备背景数据 - 确保有正确的维度
    if len(background_data.shape) == 2:
        background_data = background_data[:, np.newaxis, :]  # 添加channel维度
    background_tensor = torch.FloatTensor(background_data).to(device)

    # 创建SHAP DeepExplainer
    explainer = shap.DeepExplainer(model, background_tensor)

    # 计算SHAP值
    print("正在计算SHAP值...")
    if len(test_data.shape) == 2:
        test_data_3d = test_data[:, np.newaxis, :]  # 添加channel维度
    else:
        test_data_3d = test_data
    test_tensor = torch.FloatTensor(test_data_3d).to(device)
    shap_values = explainer.shap_values(test_tensor)

    # 将SHAP值转换回2D以便可视化
    if isinstance(shap_values, list):
        shap_values = [sv.squeeze(1) if len(sv.shape) == 3 else sv for sv in shap_values]
    else:
        shap_values = shap_values.squeeze(1) if len(shap_values.shape) == 3 else shap_values

    return explainer, shap_values


def shap_kernel_explainer_analysis(model, background_data, test_data, device, class_names=None):
    """
    使用SHAP KernelExplainer进行可解释性分析（适用于序列数据）

    Args:
        model: PyTorch模型
        background_data: 背景数据
        test_data: 测试数据
        device: 设备
        class_names: 类别名称

    Returns:
        explainer: SHAP解释器
        shap_values: SHAP值
    """
    print("正在初始化SHAP KernelExplainer...")

    # 创建模型包装器
    model_wrapper = create_model_wrapper(model, device)

    # 创建SHAP KernelExplainer
    explainer = shap.KernelExplainer(model_wrapper, background_data)

    # 计算SHAP值（对于较大的数据集，建议只选择少量样本）
    print("正在计算SHAP值...")
    shap_values = explainer.shap_values(test_data[:10])  # 只计算前10个样本以节省时间

    return explainer, shap_values


def plot_shap_summary(shap_values, test_data, class_names=None):
    """
    绘制SHAP摘要图

    Args:
        shap_values: SHAP值
        test_data: 测试数据
        class_names: 类别名称
    """
    plt.figure(figsize=(15, 10))

    # 确保test_data是2D的
    if len(test_data.shape) == 3:
        test_data = test_data.squeeze(1)

    # 如果是多分类，shap_values是一个列表
    if isinstance(shap_values, list):
        num_classes = len(shap_values)
        rows = (num_classes + 1) // 2
        cols = 2

        for i, class_shap_values in enumerate(shap_values):
            plt.subplot(rows, cols, i + 1)
            class_name = class_names[i] if class_names else f'Class {i}'

            # 确保SHAP值是2D的
            if len(class_shap_values.shape) == 3:
                class_shap_values = class_shap_values.squeeze(1)

            try:
                shap.summary_plot(class_shap_values, test_data,
                                  plot_type="dot", show=False)
                plt.title(f'SHAP Summary - {class_name}', fontsize=14)
            except Exception as e:
                print(f"绘制类别 {class_name} 的摘要图时出错: {e}")
                # 使用简单的条形图作为替代
                avg_importance = np.mean(np.abs(class_shap_values), axis=0)
                plt.bar(range(len(avg_importance)), avg_importance)
                plt.title(f'Feature Importance - {class_name}', fontsize=14)
                plt.xlabel('Feature Index')
                plt.ylabel('Average |SHAP Value|')
    else:
        # 确保SHAP值是2D的
        if len(shap_values.shape) == 3:
            shap_values = shap_values.squeeze(1)

        try:
            shap.summary_plot(shap_values, test_data, plot_type="dot", show=False)
            plt.title('SHAP Summary Plot', fontsize=14)
        except Exception as e:
            print(f"绘制摘要图时出错: {e}")
            # 使用简单的条形图作为替代
            avg_importance = np.mean(np.abs(shap_values), axis=0)
            plt.bar(range(len(avg_importance)), avg_importance)
            plt.title('Feature Importance', fontsize=14)
            plt.xlabel('Feature Index')
            plt.ylabel('Average |SHAP Value|')

    plt.tight_layout()
    plt.show()


def plot_shap_waterfall(shap_values, test_data, instance_idx=0, class_idx=0, class_names=None):
    """
    绘制SHAP瀑布图

    Args:
        shap_values: SHAP值
        test_data: 测试数据
        instance_idx: 样本索引
        class_idx: 类别索引
        class_names: 类别名称
    """
    plt.figure(figsize=(12, 8))

    # 确保数据是2D的
    if len(test_data.shape) == 3:
        test_data = test_data.squeeze(1)

    # 选择特定样本和类别的SHAP值
    if isinstance(shap_values, list):
        values = shap_values[class_idx][instance_idx]
        if len(values.shape) > 1:
            values = values.flatten()
    else:
        values = shap_values[instance_idx]
        if len(values.shape) > 1:
            values = values.flatten()

    # 创建特征名称
    feature_names = [f'Feature_{i}' for i in range(len(values))]

    try:
        # 创建SHAP Explanation对象
        explanation = shap.Explanation(
            values=values,
            base_values=0,  # 基准值
            data=test_data[instance_idx],
            feature_names=feature_names
        )

        class_name = class_names[class_idx] if class_names else f'Class {class_idx}'
        shap.waterfall_plot(explanation, show=False)
        plt.title(f'SHAP Waterfall Plot - Sample {instance_idx}, {class_name}', fontsize=14)
    except Exception as e:
        print(f"绘制瀑布图时出错: {e}")
        # 使用简单的条形图作为替代
        sorted_indices = np.argsort(np.abs(values))[::-1][:20]  # 显示前20个最重要的特征
        sorted_values = values[sorted_indices]
        sorted_names = [feature_names[i] for i in sorted_indices]

        colors = ['red' if v < 0 else 'blue' for v in sorted_values]
        plt.barh(range(len(sorted_values)), sorted_values, color=colors)
        plt.yticks(range(len(sorted_values)), sorted_names)
        plt.xlabel('SHAP Value')
        plt.title(f'Top 20 Feature Contributions - Sample {instance_idx}', fontsize=14)
        plt.gca().invert_yaxis()

    plt.tight_layout()
    plt.show()


def plot_shap_force_plot(explainer, shap_values, test_data, instance_idx=0, class_idx=0):
    """
    绘制SHAP力图

    Args:
        explainer: SHAP解释器
        shap_values: SHAP值
        test_data: 测试数据
        instance_idx: 样本索引
        class_idx: 类别索引
    """
    if isinstance(shap_values, list):
        values = shap_values[class_idx][instance_idx]
        base_value = explainer.expected_value[class_idx]
    else:
        values = shap_values[instance_idx]
        base_value = explainer.expected_value

    # 创建力图
    force_plot = shap.force_plot(
        base_value,
        values,
        test_data[instance_idx],
        matplotlib=True,
        show=False
    )

    plt.figure(figsize=(15, 3))
    plt.title(f'SHAP Force Plot - Sample {instance_idx}', fontsize=14)
    plt.show()


def plot_feature_importance_heatmap(shap_values, class_names=None):
    """
    绘制特征重要性热图

    Args:
        shap_values: SHAP值
        class_names: 类别名称
    """
    plt.figure(figsize=(12, 8))

    if isinstance(shap_values, list):
        # 计算每个类别的平均绝对SHAP值
        importance_matrix = []
        for i, class_shap_values in enumerate(shap_values):
            avg_importance = np.mean(np.abs(class_shap_values), axis=0)
            importance_matrix.append(avg_importance)

        importance_matrix = np.array(importance_matrix)

        # 创建热图
        class_labels = class_names if class_names else [f'Class {i}' for i in range(len(shap_values))]
        feature_labels = [f'F{i}' for i in range(importance_matrix.shape[1])]

        sns.heatmap(importance_matrix,
                    xticklabels=feature_labels[::max(1, len(feature_labels) // 20)],  # 显示部分特征标签
                    yticklabels=class_labels,
                    annot=False,
                    cmap='RdYlBu_r',
                    cbar_kws={'label': 'Average |SHAP Value|'})

        plt.title('Feature Importance Heatmap Across Classes', fontsize=14)
        plt.xlabel('Features', fontsize=12)
        plt.ylabel('Classes', fontsize=12)
    else:
        # 单分类情况
        avg_importance = np.mean(np.abs(shap_values), axis=0)
        plt.plot(avg_importance)
        plt.title('Feature Importance', fontsize=14)
        plt.xlabel('Feature Index', fontsize=12)
        plt.ylabel('Average |SHAP Value|', fontsize=12)

    plt.tight_layout()
    plt.show()


def analyze_top_features(shap_values, feature_threshold=0.01, class_names=None):
    """
    分析最重要的特征

    Args:
        shap_values: SHAP值
        feature_threshold: 特征重要性阈值
        class_names: 类别名称
    """
    print("=== 特征重要性分析 ===")

    if isinstance(shap_values, list):
        for i, class_shap_values in enumerate(shap_values):
            class_name = class_names[i] if class_names else f'Class {i}'
            print(f"\n{class_name}:")

            # 计算平均绝对SHAP值
            avg_importance = np.mean(np.abs(class_shap_values), axis=0)

            # 找出重要特征
            important_indices = np.where(avg_importance > feature_threshold)[0]
            important_values = avg_importance[important_indices]

            # 排序
            sorted_indices = np.argsort(important_values)[::-1]

            print(f"  重要特征数量: {len(important_indices)}")
            print(f"  前10个最重要特征:")
            for j, idx in enumerate(sorted_indices[:10]):
                feature_idx = important_indices[idx]
                importance = important_values[idx]
                print(f"    特征 {feature_idx}: {importance:.4f}")
    else:
        avg_importance = np.mean(np.abs(shap_values), axis=0)
        important_indices = np.where(avg_importance > feature_threshold)[0]
        important_values = avg_importance[important_indices]
        sorted_indices = np.argsort(important_values)[::-1]

        print(f"重要特征数量: {len(important_indices)}")
        print(f"前10个最重要特征:")
        for j, idx in enumerate(sorted_indices[:10]):
            feature_idx = important_indices[idx]
            importance = important_values[idx]
            print(f"  特征 {feature_idx}: {importance:.4f}")


def main_shap_analysis(model, test_loader, device, class_names=None, use_deep_explainer=True):
    """
    主要的SHAP分析函数

    Args:
        model: PyTorch模型
        test_loader: 测试数据加载器
        device: 设备
        class_names: 类别名称
        use_deep_explainer: 是否使用DeepExplainer
    """
    print("开始SHAP可解释性分析...")

    # 准备数据
    background_data, test_data, test_labels = prepare_shap_data(test_loader, num_samples=100)
    print(f"背景数据形状: {background_data.shape}")
    print(f"测试数据形状: {test_data.shape}")

    # 设置类别名称
    if class_names is None:
        class_names = [f'Class {i}' for i in range(4)]

    try:
        if use_deep_explainer:
            # 使用DeepExplainer
            explainer, shap_values = shap_deep_explainer_analysis(
                model, background_data, test_data, device, class_names
            )
        else:
            # 使用KernelExplainer
            explainer, shap_values = shap_kernel_explainer_analysis(
                model, background_data, test_data, device, class_names
            )

        print("SHAP值计算完成！")

        # 绘制各种可视化图
        print("\n1. 绘制SHAP摘要图...")
        plot_shap_summary(shap_values, test_data, class_names)

        print("\n2. 绘制特征重要性热图...")
        plot_feature_importance_heatmap(shap_values, class_names)

        print("\n3. 绘制SHAP瀑布图（样本0，类别0）...")
        plot_shap_waterfall(shap_values, test_data, instance_idx=0, class_idx=0, class_names=class_names)

        # 如果使用DeepExplainer，可以绘制力图
        if use_deep_explainer:
            print("\n4. 绘制SHAP力图...")
            try:
                plot_shap_force_plot(explainer, shap_values, test_data, instance_idx=0, class_idx=0)
            except Exception as e:
                print(f"力图绘制失败: {e}")

        print("\n5. 分析重要特征...")
        analyze_top_features(shap_values, feature_threshold=0.01, class_names=class_names)

        return explainer, shap_values, test_data, test_labels

    except Exception as e:
        print(f"SHAP分析过程中出现错误: {e}")
        print("尝试使用KernelExplainer...")

        if use_deep_explainer:
            # 如果DeepExplainer失败，尝试KernelExplainer
            return main_shap_analysis(model, test_loader, device, class_names, use_deep_explainer=False)
        else:
            raise e


# 执行SHAP分析
# 设置类别名称（根据你的实际类别修改）
class_names = ['类别0', '类别1', '类别2', '类别3']  # 修改为你的实际类别名称

# 执行分析
try:
    explainer, shap_values, test_data, test_labels = main_shap_analysis(
        model,
        test_loader,
        device,
        class_names=class_names,
        use_deep_explainer=True  # 可以设置为False使用KernelExplainer
    )
    print("SHAP可解释性分析完成！")
except Exception as e:
    print(f"标准SHAP分析失败: {e}")
    print("尝试简化版分析...")

    # 简化版分析 - 直接使用KernelExplainer和更小的数据集
    try:
        # 准备更小的数据集
        background_data, test_data, test_labels = prepare_shap_data(test_loader, num_samples=50)

        # 创建模型包装器
        model_wrapper = create_model_wrapper(model, device)

        # 使用更少的背景数据
        small_background = background_data[:10]  # 只用10个背景样本
        small_test = test_data[:5]  # 只分析5个测试样本

        print(f"简化分析 - 背景数据: {small_background.shape}, 测试数据: {small_test.shape}")

        # 创建KernelExplainer
        explainer = shap.KernelExplainer(model_wrapper, small_background)
        shap_values = explainer.shap_values(small_test)

        # 绘制简化的可视化
        print("绘制特征重要性图...")
        plot_feature_importance_heatmap(shap_values, class_names)

        print("分析重要特征...")
        analyze_top_features(shap_values, feature_threshold=0.001, class_names=class_names)

        print("简化版SHAP分析完成！")

    except Exception as e2:
        print(f"简化版分析也失败: {e2}")
        print("请检查模型和数据的兼容性")