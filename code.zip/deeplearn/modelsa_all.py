# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：modelsa_all.py
    @时间：2025/9/23 18:00
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import torch
import torch.nn as nn
from SCmodule import ScConv1d
from ResNet1D import BasicBlock1D

class CNN1D(nn.Module):
    """一维CNN模型用于5分类"""

    def __init__(self, num_classes):
        super(CNN1D, self).__init__()

        # 第一层卷积块
        self.conv1 = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(3, 1)
        )

        # 第二层卷积块
        self.conv2 = nn.Sequential(
            nn.Conv1d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(3, 1)
        )

        # 第三层卷积块
        self.conv3 = nn.Sequential(
            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.MaxPool1d(3, 1)
        )

        # self.sc = ScConv1d(128)

        # 自适应池化层
        self.adaptive_pool = nn.AdaptiveAvgPool1d(1)

        # 全连接层
        self.fc = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):

        x = self.conv1(x)

        x = self.conv2(x)

        x = self.conv3(x)

        x = self.adaptive_pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

class FeatureTransformer(nn.Module):
    def __init__(self, input_dim, embed_dim, num_heads, num_layers):
        super(FeatureTransformer, self).__init__()

        # Embedding层，用于将每个光谱数据映射到高维空间
        self.embedding = nn.Linear(input_dim, embed_dim)

        # 位置编码，可以使用固定的位置编码，也可以学习
        self.positional_encoding = nn.Parameter(torch.zeros(1, 1, embed_dim))

        # Transformer编码器层
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)


    def forward(self, x1):

        x = self.embedding(x1)

        y = self.positional_encoding

        # 添加位置编码
        x = x + y

        # Transformer编码
        x = self.transformer_encoder(x)


        return x


class MLP1D(nn.Module):
    """
    一维输入五分类 MLP：
    """
    def __init__(self, num_classes=5):
        super(MLP1D, self).__init__()
        self.fc1 = nn.Linear(128, 256)
        self.bn1 = nn.BatchNorm1d(256)
        self.dropout1 = nn.Dropout(0.3)

        self.fc2 = nn.Linear(256, 128)
        self.bn2 = nn.BatchNorm1d(128)
        self.dropout2 = nn.Dropout(0.3)

        self.fc3 = nn.Linear(128, 64)
        self.bn3 = nn.BatchNorm1d(64)
        self.dropout3 = nn.Dropout(0.3)

        self.fc4 = nn.Linear(64, num_classes)

    def forward(self, x):
        x = self.dropout1(torch.relu(self.bn1(self.fc1(x))))
        x = self.dropout2(torch.relu(self.bn2(self.fc2(x))))
        x = self.dropout3(torch.relu(self.bn3(self.fc3(x))))
        return self.fc4(x)

class MSCA(nn.Module):
    """
    MSCA模型
    """
    def __init__(self, num_classes=5):
        super(MSCA, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv1d(1, 16, kernel_size=3, padding=1),
            nn.BatchNorm1d(16),
            nn.ReLU(),
            nn.MaxPool1d(3, 1),
        )

        self.conv2 = nn.Sequential(
            nn.Conv1d(16, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )

        self.trans = FeatureTransformer(input_dim=36, embed_dim=36, num_heads=4, num_layers=2)

        self.resnet1 = BasicBlock1D(in_planes=16, planes=16, stride=1)
        self.resnet2 = BasicBlock1D(in_planes=64, planes=64, stride=1)

        self.sc_conv1 = ScConv1d(64)

        # self.sc_conv2 = ScConv1d(256)

        self.avg_pool = nn.AdaptiveAvgPool1d(1)

        self.fc = nn.Sequential(
            nn.Linear(64, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )



    def forward(self, x):

        x = self.trans(x)
        # 增加一个通道维度1
        # x = x.unsqueeze(1)

        x = self.conv1(x)


        x = self.resnet1(x)

        x = self.conv2(x)
        x = self.resnet2(x)

        x = self.sc_conv1(x)

        x = self.avg_pool(x)

        x = nn.Flatten()(x)
        x = self.fc(x)

        return x


def get_model(num_classes=3):
    """
    获取模型
    :param num_classes:
    :return: 模型
    """
    model = MSCA(num_classes=num_classes)
    # model = MLP1D(num_classes=num_classes)
    # model = CNN1D(num_classes=num_classes)

    print(f"模型参数数量: {sum(p.numel() for p in model.parameters())}")

    return model