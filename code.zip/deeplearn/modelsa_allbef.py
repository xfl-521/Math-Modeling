# -*- coding: utf-8 -*-
"""
-------------------------------
    @软件：PyCharm
    @PyCharm：2023
    @Python：3.8
    @项目：MathModel
-------------------------------
    @文件：modelsa_all.py
    @时间：2025/9/23 18:00
    @作者：XFK
    @邮箱：fkxing2000@163.com
# -------------------------------
"""
import torch
import torch.nn as nn
from ResNet1D import BasicBlock1D


class FeatureTransformer(nn.Module):
    def __init__(self, input_dim, embed_dim, num_heads, num_layers):
        super(FeatureTransformer, self).__init__()

        # Embedding层，用于将每个光谱数据映射到高维空间
        self.embedding = nn.Linear(input_dim, embed_dim)

        # 位置编码，可以使用固定的位置编码，也可以学习
        self.positional_encoding = nn.Parameter(torch.zeros(1, 1, embed_dim))

        # Transformer编码器层
        encoder_layer = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=num_heads, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

    def forward(self, x):
        x = self.embedding(x)

        y = self.positional_encoding

        # 添加位置编码
        x = x + y

        # Transformer编码
        x = self.transformer_encoder(x)

        return x


import torch
import torch.nn as nn
import torch.nn.functional as F


# ------------------- 一维 GroupBatchNorm -------------------
class GroupBatchnorm1d(nn.Module):
    def __init__(self, c_num: int, group_num: int = 16, eps: float = 1e-10):
        super().__init__()
        assert c_num >= group_num
        self.group_num = group_num
        self.weight = nn.Parameter(torch.randn(c_num, 1))
        self.bias = nn.Parameter(torch.zeros(c_num, 1))
        self.eps = eps

    def forward(self, x):
        # x: (B, C, L)
        b, c, l = x.shape
        x = x.view(b, self.group_num, -1)  # (B, G, -1)
        mean = x.mean(dim=2, keepdim=True)
        std = x.std(dim=2, keepdim=True)
        x = (x - mean) / (std + self.eps)
        x = x.view(b, c, l)
        return x * self.weight + self.bias


# ------------------- 一维 SRU -------------------
class SRU1d(nn.Module):
    def __init__(self,
                 oup_channels: int,
                 group_num: int = 16,
                 gate_threshold: float = 0.5,
                 torch_gn: bool = True):
        super().__init__()
        if torch_gn:
            self.gn = nn.GroupNorm(num_groups=group_num, num_channels=oup_channels)
        else:
            self.gn = GroupBatchnorm1d(c_num=oup_channels, group_num=group_num)
        self.gate_threshold = gate_threshold
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        gn_x = self.gn(x)  # (B, C, L)
        w_gamma = (self.gn.weight / self.gn.weight.sum()).view(1, -1, 1)
        reweigts = self.sigmoid(gn_x * w_gamma)  # (B, C, L)
        w1 = torch.where(reweigts > self.gate_threshold,
                         torch.ones_like(reweigts), reweigts)
        w2 = torch.where(reweigts > self.gate_threshold,
                         torch.zeros_like(reweigts), reweigts)
        x1, x2 = w1 * x, w2 * x
        return self.reconstruct(x1, x2)

    def reconstruct(self, x1, x2):
        x11, x12 = torch.chunk(x1, 2, dim=1)
        x21, x22 = torch.chunk(x2, 2, dim=1)
        return torch.cat([x11 + x22, x12 + x21], dim=1)


# ------------------- 一维 CRU -------------------
class CRU1d(nn.Module):
    def __init__(self,
                 op_channel: int,
                 alpha: float = 0.5,
                 squeeze_radio: int = 2,
                 group_size: int = 2,
                 group_kernel_size: int = 3):
        super().__init__()
        up_channel = int(alpha * op_channel)
        low_channel = op_channel - up_channel
        self.up_channel, self.low_channel = up_channel, low_channel

        self.squeeze1 = nn.Conv1d(up_channel, up_channel // squeeze_radio, 1, bias=False)
        self.squeeze2 = nn.Conv1d(low_channel, low_channel // squeeze_radio, 1, bias=False)

        # up branch
        self.GWC = nn.Conv1d(up_channel // squeeze_radio, op_channel,
                             kernel_size=group_kernel_size, padding=group_kernel_size // 2,
                             groups=group_size, bias=False)
        self.PWC1 = nn.Conv1d(up_channel // squeeze_radio, op_channel, 1, bias=False)

        # low branch
        self.PWC2 = nn.Conv1d(low_channel // squeeze_radio,
                              op_channel - low_channel // squeeze_radio, 1, bias=False)
        self.advavg = nn.AdaptiveAvgPool1d(1)

    def forward(self, x):
        up, low = torch.split(x, [self.up_channel, self.low_channel], dim=1)

        up, low = self.squeeze1(up), self.squeeze2(low)

        Y1 = self.GWC(up) + self.PWC1(up)
        Y2 = torch.cat([self.PWC2(low), low], dim=1)

        out = torch.cat([Y1, Y2], dim=1)
        att = F.softmax(self.advavg(out), dim=1)  # (B, C, 1)
        out = att * out
        out1, out2 = torch.chunk(out, 2, dim=1)
        return out1 + out2


class MSCA(nn.Module):
    """
    MSCA模型
    """

    def __init__(self, num_classes=5):
        super(MSCA, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv1d(1, 16, kernel_size=3, padding=1),
            nn.BatchNorm1d(16),
            nn.ReLU(),
            nn.MaxPool1d(3, 1),
        )

        self.conv2 = nn.Sequential(
            nn.Conv1d(16, 64, kernel_size=3, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(2),
        )

        self.trans = FeatureTransformer(input_dim=92, embed_dim=256, num_heads=4, num_layers=2)

        self.resnet1 = BasicBlock1D(in_planes=16, planes=16, stride=1)
        self.resnet2 = BasicBlock1D(in_planes=64, planes=64, stride=1)

        self.sc_conv1 = ScConv1d(64)

        # self.sc_conv2 = ScConv1d(256)

        self.avg_pool = nn.AdaptiveAvgPool1d(1)

        self.fc = nn.Sequential(
            nn.Linear(64, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )

    def forward(self, x):
        x = self.trans(x)
        # 增加一个通道维度1
        # x = x.unsqueeze(1)

        x = self.conv1(x)
        x = self.resnet1(x)
        x = self.conv2(x)
        x = self.resnet2(x)
        x = self.sc_conv1(x)
        x = self.avg_pool(x)

        x = nn.Flatten()(x)
        x = self.fc(x)

        return x


def get_model(num_classes=3):
    """
    获取模型
    :param num_classes:
    :return: 模型
    """
    model = MSCA(num_classes=num_classes)

    print(f"模型参数数量: {sum(p.numel() for p in model.parameters())}")

    return model
